package
{
   import adobe.utils.*;
   import bobby.§ null§;
   import flash.accessibility.*;
   import flash.desktop.*;
   import flash.display.*;
   import flash.errors.*;
   import flash.events.*;
   import flash.external.*;
   import flash.filters.*;
   import flash.geom.*;
   import flash.globalization.*;
   import flash.media.*;
   import flash.net.*;
   import flash.net.drm.*;
   import flash.printing.*;
   import flash.profiler.*;
   import flash.sampler.*;
   import flash.sensors.*;
   import flash.system.*;
   import flash.text.*;
   import flash.text.engine.*;
   import flash.text.ime.*;
   import flash.ui.*;
   import flash.utils.*;
   import flash.xml.*;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol171")]
   public dynamic class Symbol30copy7 extends § null§
   {
      
      public function Symbol30copy7()
      {
         super();
         addFrameScript(0,this.frame1,14,this.frame15,26,this.frame27);
      }
      
      internal function frame1() : *
      {
         stop();
      }
      
      internal function frame15() : *
      {
         MovieClip(parent).swingBack();
      }
      
      internal function frame27() : *
      {
         MovieClip(parent).setupOverhead();
      }
   }
}

