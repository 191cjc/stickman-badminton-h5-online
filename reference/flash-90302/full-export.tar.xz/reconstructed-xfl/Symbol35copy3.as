package
{
   import bobby.§ null§;
   
   public dynamic class Symbol35copy3 extends § null§
   {
      
      public function Symbol35copy3()
      {
         super();
      }
   }
}

