package
{
   import bobby.§ null§;
   
   public dynamic class Symbol30copy8 extends § null§
   {
      
      public function Symbol30copy8()
      {
         super();
      }
   }
}

