package fx
{
   import bobby.§ null§;
   import flash.events.Event;
   
   public class BigSpark extends § null§
   {
      
      public function BigSpark()
      {
         super();
      }
      
      override public function handleStageAdd(param1:Event) : void
      {
         super.handleStageAdd(param1);
      }
      
      override public function handleEnterFrame(param1:Number) : void
      {
         super.handleEnterFrame(param1);
      }
      
      override public function handleRemove(param1:Event) : void
      {
         super.handleRemove(param1);
      }
   }
}

