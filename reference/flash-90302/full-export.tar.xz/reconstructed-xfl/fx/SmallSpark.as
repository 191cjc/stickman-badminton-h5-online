package fx
{
   import bobby.§ null§;
   import flash.events.Event;
   
   public class SmallSpark extends § null§
   {
      
      public function SmallSpark()
      {
         super();
      }
      
      override public function handleStageAdd(param1:Event) : void
      {
         super.handleStageAdd(param1);
      }
      
      override public function handleEnterFrame(param1:Number) : void
      {
         super.handleEnterFrame(param1);
      }
      
      override public function handleRemove(param1:Event) : void
      {
         super.handleRemove(param1);
      }
   }
}

