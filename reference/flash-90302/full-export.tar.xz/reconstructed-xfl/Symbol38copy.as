package
{
   import bobby.§ null§;
   
   public dynamic class Symbol38copy extends § null§
   {
      
      public function Symbol38copy()
      {
         super();
      }
   }
}

