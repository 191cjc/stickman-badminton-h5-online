package bobby.classes
{
   import bobby.§ null§;
   
   public class PauseScreen extends § null§
   {
      
      public function PauseScreen()
      {
         super();
      }
   }
}

