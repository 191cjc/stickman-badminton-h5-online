package
{
   import bobby.§ null§;
   
   public dynamic class Symbol34copy extends § null§
   {
      
      public function Symbol34copy()
      {
         super();
      }
   }
}

