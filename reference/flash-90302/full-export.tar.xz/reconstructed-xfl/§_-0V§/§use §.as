package §_-0V§
{
   import flash.display.MovieClip;
   import flash.events.Event;
   
   public class §use § extends §_-h§
   {
      
      public var overheadSwing:Symbol30copy2ragdag;
      
      public var servePoint:MovieClip;
      
      public var underHitbox:MovieClip;
      
      public var underhandSwing:Symbol30copy2agr;
      
      public var serveSwing:Symbol30copy3;
      
      public var computerHitbox:MovieClip;
      
      public function §use §()
      {
         super();
         §case § = 0.89;
         include = 1.25;
         §do§ = 1;
         §_-4d§.push("Cheerio.");
         §_-5c§.push("Why I think I have scored!");
         §_-5c§.push("Goody.");
         §_-1H§.push("Well played old chap!");
         §_-1H§.push("Quite the shot.");
         §_-2I§.push("Good match chap!");
         §_-X§.push("Oh my.");
      }
      
      override public function handleStageAdd(param1:Event) : void
      {
         super.handleStageAdd(param1);
      }
      
      override public function handleEnterFrame(param1:Number) : void
      {
         super.handleEnterFrame(param1);
      }
      
      override public function handleRemove(param1:Event) : void
      {
         super.handleRemove(param1);
      }
   }
}

