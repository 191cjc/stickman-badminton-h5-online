package whipcrack2_01
{
   import flash.media.Sound;
   
   public dynamic class mp3 extends Sound
   {
      
      public function mp3()
      {
         super();
      }
   }
}

