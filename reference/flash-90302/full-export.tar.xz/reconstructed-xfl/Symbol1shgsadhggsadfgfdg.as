package
{
   import bobby.§ null§;
   
   public dynamic class Symbol1shgsadhggsadfgfdg extends § null§
   {
      
      public function Symbol1shgsadhggsadfgfdg()
      {
         super();
      }
   }
}

