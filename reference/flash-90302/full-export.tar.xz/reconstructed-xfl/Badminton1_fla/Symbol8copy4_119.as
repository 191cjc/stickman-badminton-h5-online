package Badminton1_fla
{
   import flash.display.MovieClip;
   
   public dynamic class Symbol8copy4_119 extends MovieClip
   {
      
      public function Symbol8copy4_119()
      {
         super();
      }
   }
}

