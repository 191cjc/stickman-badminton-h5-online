package Badminton1_fla
{
   import flash.display.MovieClip;
   
   public dynamic class Symbol62copy_222 extends MovieClip
   {
      
      public function Symbol62copy_222()
      {
         super();
      }
   }
}

