package Badminton1_fla
{
   import flash.display.MovieClip;
   
   public dynamic class Symbol8copy2_72 extends MovieClip
   {
      
      public function Symbol8copy2_72()
      {
         super();
      }
   }
}

