package Badminton1_fla
{
   import flash.display.MovieClip;
   
   public dynamic class Symbol1hreahejerhr_152 extends MovieClip
   {
      
      public var hero:Symbol38copy;
      
      public var servePoint:MovieClip;
      
      public var serveSwing:Symbol30copy2;
      
      public function Symbol1hreahejerhr_152()
      {
         super();
      }
   }
}

