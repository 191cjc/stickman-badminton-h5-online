package
{
   import bobby.§ null§;
   
   public dynamic class Symbol30copy2 extends § null§
   {
      
      public function Symbol30copy2()
      {
         super();
      }
   }
}

