package
{
   import bobby.§ null§;
   
   public dynamic class Symbol30copy extends § null§
   {
      
      public function Symbol30copy()
      {
         super();
      }
   }
}

