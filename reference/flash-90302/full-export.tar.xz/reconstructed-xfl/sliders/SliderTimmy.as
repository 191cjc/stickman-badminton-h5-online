package sliders
{
   import flash.display.MovieClip;
   
   public dynamic class SliderTimmy extends MovieClip
   {
      
      public var racket:MovieClip;
      
      public function SliderTimmy()
      {
         super();
      }
   }
}

