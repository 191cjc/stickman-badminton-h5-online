package sliders
{
   import flash.display.MovieClip;
   
   public dynamic class SliderRobot extends MovieClip
   {
      
      public function SliderRobot()
      {
         super();
      }
   }
}

