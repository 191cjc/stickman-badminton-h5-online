package sliders
{
   import flash.display.MovieClip;
   
   public dynamic class SliderJoe extends MovieClip
   {
      
      public var hero:Symbol38copy;
      
      public var servePoint:MovieClip;
      
      public var serveSwing:Symbol30copy2;
      
      public function SliderJoe()
      {
         super();
      }
   }
}

