package sliders
{
   import flash.display.MovieClip;
   
   public dynamic class SliderTopHat extends MovieClip
   {
      
      public var hero:Symbol38copy;
      
      public var servePoint:MovieClip;
      
      public var serveSwing:Symbol30copy2;
      
      public function SliderTopHat()
      {
         super();
      }
   }
}

