function mouseIn()
{
   bar.closeButton._visible = true;
   cancelHide();
   _alpha = 100;
   cancelOpenClose();
   bar.game.transform.colorTransform = new flash.geom.ColorTransform(1,1,1,1,32,32,0,0);
}
function mouseOut()
{
   scheduleClose(1500);
   scheduleHide(1500);
   bar.game.transform.colorTransform = new flash.geom.ColorTransform();
}
stop();
bar.game.transform.colorTransform = new flash.geom.ColorTransform(1,1,1,1,32,32,0,0);
bar.game.onRelease = function()
{
   getURL(myCreative.clickAction,"blank");
};
