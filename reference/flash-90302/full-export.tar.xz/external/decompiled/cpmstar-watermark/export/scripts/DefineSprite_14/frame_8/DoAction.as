scheduleClose(1500);
stop();
