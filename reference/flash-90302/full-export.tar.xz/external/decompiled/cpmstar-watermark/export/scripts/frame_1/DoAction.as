function onEnterFrame()
{
   var _loc2_;
   if(creativesLoader == null)
   {
      creativesLoader = new CreativesLoader();
      creativesLoader.onLoad = function(success)
      {
         onCreativesLoaded(success);
      };
      creativesLoader.load(1,this.poolid,this.subpoolid,this.contentspotid);
   }
}
function onCreativesLoaded(success)
{
   if(!success)
   {
      return undefined;
   }
   if(creativesLoader.creatives.length < 1)
   {
      return undefined;
   }
   slide_out_bar.setCreative(creativesLoader.creatives[0]);
   slide_out_bar._visible = true;
   slide_out_bar.play();
}
var creativesLoader;
slide_out_bar._visible = false;
