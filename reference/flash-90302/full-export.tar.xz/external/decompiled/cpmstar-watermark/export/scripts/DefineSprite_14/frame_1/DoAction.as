function mouseIn()
{
   bar.closeButton._visible = true;
   cancelHide();
   _alpha = 100;
   scheduleOpen(500);
}
function mouseOut()
{
   _alpha = 50;
   cancelOpenClose();
   scheduleHide(1500);
}
function onEnterFrame()
{
   var _loc2_;
   if(_alpha == 100)
   {
      _loc2_ = transform.colorTransform;
      if(_loc2_.redOffset != 0)
      {
         _loc2_.redOffset = 0;
         transform.colorTransform = _loc2_;
      }
      return undefined;
   }
   var _loc1_ = getTimer() % 13000;
   if(_loc1_ > 0 && _loc1_ < 500)
   {
      _alpha = 50 + 50 * _loc1_ / 500;
      _loc2_ = transform.colorTransform;
      _loc2_.redOffset = 0 + 100 * _loc1_ / 500;
      transform.colorTransform = _loc2_;
   }
   else if(_loc1_ > 500 && _loc1_ < 1000)
   {
      _alpha = 100 - 50 * (_loc1_ - 500) / 500;
      _loc2_ = transform.colorTransform;
      _loc2_.redOffset = 100 - 100 * (_loc1_ - 500) / 500;
      transform.colorTransform = _loc2_;
   }
   else if(alpha != 50)
   {
      alpha = 50;
      _loc2_ = transform.colorTransform;
      _loc2_.redOffset = 0;
      transform.colorTransform = _loc2_;
   }
}
function cancelOpenClose()
{
   clearTimeout(tim);
   tim = -1;
}
function scheduleOpen(ms)
{
   cancelOpenClose();
   tim = setTimeout(function()
   {
      gotoAndStop("closed");
      play();
   }
   ,500);
}
function scheduleClose(ms)
{
   cancelOpenClose();
   var _loc2_ = this;
   tim = setTimeout(function()
   {
      gotoAndStop("firstClose");
      play();
   }
   ,ms);
}
function cancelHide()
{
   clearTimeout(tim2);
   tim2 = -1;
}
function scheduleHide(ms)
{
   cancelHide();
   tim2 = setTimeout(function()
   {
      bar.closeButton._visible = false;
   }
   ,ms);
}
function setCreative(creative)
{
   bar.game.txt.htmlText = "<b><u>" + creative.title + "</u></b>";
   bar.game.desc.htmlText = creative.desc;
   bar.game.img.createEmptyMovieClip("img",0);
   myCreative = creative;
   bar.game.img.img.loadMovie(creative.imageUrl);
}
bar.closeButton._visible = false;
cancelOpenClose();
if(first_ran == undefined)
{
   var first_ran = true;
}
stop();
var tim;
var tim2;
bar.game.onRelease = function()
{
   cancelOpenClose();
   gotoAndStop("closed");
   play();
};
var myCreative;
bar.game.onRollOver = function()
{
   if(_visible)
   {
      mouseIn();
   }
};
bar.game.onRollOut = function()
{
   mouseOut();
};
bar.closeButton.onRollOut = function()
{
   mouseOut();
};
bar.closeButton.onRollOver = function()
{
   if(_visible)
   {
      mouseIn();
   }
};
bar.closeButton.onRelease = function()
{
   _parent._y = 2000;
   _parent._visible = false;
};
