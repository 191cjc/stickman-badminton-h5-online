function mouseIn()
{
   bar.closeButton._visible = true;
   cancelHide();
   _alpha = 100;
   cancelOpenClose();
}
function mouseOut()
{
   scheduleClose(1500);
   scheduleHide(1500);
}
cancelOpenClose();
delete bar.game.onRelease;
