function mouseIn()
{
   bar.closeButton._visible = true;
   cancelHide();
   _alpha = 100;
   scheduleOpen(500);
}
bar.game.colorTransform = new ColorTransform();
