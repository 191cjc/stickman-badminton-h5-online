_alpha = 50;
gotoAndStop("closed");
