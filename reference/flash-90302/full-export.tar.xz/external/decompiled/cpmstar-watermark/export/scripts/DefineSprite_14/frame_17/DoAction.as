function mouseIn()
{
   bar.closeButton._visible = true;
   cancelHide();
   _alpha = 100;
   scheduleOpen(500);
}
function mouseOut()
{
   _alpha = 50;
   cancelOpenClose();
   scheduleHide(1500);
}
function scheduleClose(ms)
{
   cancelOpenClose();
   var _loc2_ = this;
   tim = setTimeout(function()
   {
      gotoAndStop("close");
      play();
   }
   ,ms);
}
bar.game.onRelease = function()
{
   gotoAndStop("open");
   play();
};
