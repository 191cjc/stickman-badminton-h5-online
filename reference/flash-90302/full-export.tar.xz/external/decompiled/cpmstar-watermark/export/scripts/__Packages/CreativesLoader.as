class CreativesLoader
{
   var creatives;
   var urlLoader;
   var serverUrl = "http://server.cpmstar.com/";
   var loaded = false;
   function CreativesLoader()
   {
   }
   function load(count, poolid, subpoolid, contentspotid)
   {
      if(this.loaded)
      {
         return undefined;
      }
      if(contentspotid == null && poolid == null)
      {
         return undefined;
      }
      this.loaded = true;
      this.urlLoader = new XML();
      this.urlLoader.ignoreWhite = true;
      this.urlLoader.onHTTPStatus = function(status)
      {
      };
      var t = this;
      this.urlLoader.onLoad = function(success)
      {
         t.onLoaded(success);
      };
      var _loc2_;
      if(contentspotid != null)
      {
         _loc2_ = this.serverUrl + "viewcontent.aspx?xml=1&adtypeid=24&multi=" + count + "&contentspotid=" + contentspotid;
      }
      else
      {
         _loc2_ = this.serverUrl + "view.aspx?xml=1&adtypeid=24&multi=" + count + "&poolid=" + poolid + "&subpoolid=" + subpoolid;
      }
      this.urlLoader.load(_loc2_);
   }
   function onLoad(success)
   {
   }
   function onLoaded(success)
   {
      if(!success)
      {
         this.onLoad(success);
         return undefined;
      }
      this.creatives = [];
      var _loc9_ = 0;
      var _loc14_ = this.urlLoader.firstChild;
      var _loc6_ = _loc14_.firstChild;
      var _loc10_;
      var _loc7_;
      var _loc8_;
      var _loc11_;
      var _loc3_;
      var _loc5_;
      var _loc2_;
      var _loc4_;
      while(_loc6_ != null)
      {
         _loc10_ = null;
         _loc7_ = null;
         _loc8_ = null;
         _loc11_ = null;
         _loc3_ = _loc6_.firstChild;
         while(_loc3_ != null)
         {
            switch(String(_loc3_.nodeName).toLowerCase())
            {
               case "macros":
                  _loc5_ = _loc3_;
                  _loc2_ = _loc5_.firstChild;
                  while(_loc2_ != null)
                  {
                     _loc4_ = String(_loc2_.attributes.name).toLowerCase();
                     switch(_loc4_)
                     {
                        case "image140x105":
                           _loc10_ = String(new XML(_loc2_.attributes.value).firstChild.nodeValue);
                           break;
                        case "title":
                           _loc7_ = String(new XML(_loc2_.attributes.value).firstChild.nodeValue);
                           break;
                        case "desc":
                           _loc8_ = String(new XML(_loc2_.attributes.value).firstChild.nodeValue);
                     }
                     _loc2_ = _loc2_.nextSibling;
                  }
                  break;
               case "click":
                  _loc11_ = String(_loc3_.firstChild.nodeValue);
            }
            _loc3_ = _loc3_.nextSibling;
         }
         this.creatives[_loc9_] = {imageUrl:_loc10_,clickAction:_loc11_,title:_loc7_,desc:_loc8_};
         _loc9_ = _loc9_ + 1;
         _loc6_ = _loc6_.nextSibling;
      }
      this.onLoad(success);
   }
}
