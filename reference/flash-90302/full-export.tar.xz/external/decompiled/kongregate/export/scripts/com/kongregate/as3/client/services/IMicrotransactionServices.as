package com.kongregate.as3.client.services
{
   public interface IMicrotransactionServices
   {
      
      function requestItemList(param1:Array, param2:Function) : void;
      
      function purchaseItemsRemote(param1:String, param2:Function) : void;
      
      function purchaseItems(param1:Array, param2:Function) : void;
      
      function showIncentivizedAd() : void;
      
      function requestUserItemList(param1:String, param2:Function) : void;
      
      function showKredPurchaseDialog(param1:String) : void;
      
      function initializeIncentivizedAds() : void;
      
      function useItemInstance(param1:Number, param2:Function) : void;
   }
}

