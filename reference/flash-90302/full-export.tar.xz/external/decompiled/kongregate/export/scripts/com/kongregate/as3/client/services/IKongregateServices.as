package com.kongregate.as3.client.services
{
   import flash.events.IEventDispatcher;
   
   public interface IKongregateServices extends IEventDispatcher
   {
      
      function setConnection(param1:*) : void;
      
      function getPlayerInfo(param1:Function) : void;
      
      function setMultiplayerConnection(param1:String, param2:*, param3:Object) : void;
      
      function connect(param1:Number = -1) : Boolean;
      
      function connectExternal(param1:Object = null) : Boolean;
   }
}

