package com.kongregate.as3.client.services
{
   public interface ISharedContentServices
   {
      
      function browse(param1:String, param2:String = null, param3:String = null) : void;
      
      function addLoadListener(param1:String, param2:Function) : void;
      
      function save(param1:String, param2:String, param3:Function, param4:* = null, param5:String = null) : void;
   }
}

