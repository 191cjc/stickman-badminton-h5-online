package com.kongregate.as3.client.services
{
   public class AnalyticsServiceShadow extends AbstractShadowService implements IAnalyticsServices
   {
      
      public function AnalyticsServiceShadow()
      {
         super();
      }
      
      public function setCommonProperties(param1:Object) : void
      {
         alert("analytics","setCommonProperties");
      }
      
      public function startPurchase(param1:*, param2:Object) : void
      {
         alert("analytics","startPurchase");
      }
      
      public function addEvent(param1:String, param2:Object) : void
      {
         alert("analytics","addEvent");
      }
      
      public function finishPurchase(param1:String, param2:String, param3:Object) : void
      {
         alert("analytics","finishPurchase");
      }
      
      public function setFilterType(param1:String) : void
      {
         alert("analytics","setFilterType");
      }
      
      public function getAutoLongLongProperty(param1:String) : Number
      {
         alert("analytics","getAutoLongLongProperty");
         return 0;
      }
      
      public function getAutoStringProperty(param1:String) : String
      {
         alert("analytics","getAutoStringProperty");
         return null;
      }
      
      public function getAutoPropertiesJSON() : String
      {
         alert("analytics","getAutoPropertiesJSON()");
         return null;
      }
      
      public function addFilterType(param1:String) : void
      {
         alert("analytics","addFilterType");
      }
      
      public function getAutoDoubleProperty(param1:String) : Number
      {
         alert("analytics","getAutoDoubleProperty");
         return 0;
      }
      
      public function getAutoBoolProperty(param1:String) : Boolean
      {
         alert("analytics","getAutoBoolProperty");
         return false;
      }
      
      public function setAutomaticVariablesListener(param1:Function) : void
      {
         alert("analytics","setAutomaticVariablesListener");
      }
      
      public function updateCommonProperties() : void
      {
         alert("analytics","updateCommonProperties");
      }
      
      public function setCommonPropsCallback(param1:Function) : void
      {
         alert("analytics","setCommonPropsCallback");
      }
      
      public function getAutoLongProperty(param1:String) : Number
      {
         alert("analytics","getAutoLongProperty");
         return 0;
      }
      
      public function start() : void
      {
         alert("analytics","start");
      }
      
      public function getAutoUTCProperty(param1:String) : String
      {
         alert("analytics","getAutoUTCProperty");
         return null;
      }
      
      public function getAutoIntProperty(param1:String) : int
      {
         alert("analytics","getAutoIntProperty");
         return 0;
      }
   }
}

