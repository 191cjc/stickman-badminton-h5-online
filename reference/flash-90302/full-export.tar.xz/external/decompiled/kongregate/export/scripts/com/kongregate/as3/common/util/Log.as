package com.kongregate.as3.common.util
{
   import com.adobe.serialization.json.JSON;
   import com.kongregate.as3.common.events.LogEvent;
   import flash.events.EventDispatcher;
   import flash.external.ExternalInterface;
   import flash.system.Capabilities;
   
   public class Log extends EventDispatcher
   {
      
      private static var gInstance:Log;
      
      public static const MAX_LOG_ENTRIES:Number = 250;
      
      public static var LEVELS:Array = ["Error","Warn","Info","Debug","Spam"];
      
      public static var LEVELS_MAP:Object = {
         "Error":1,
         "Warn":2,
         "Info":3,
         "Debug":4,
         "Spam":5
      };
      
      private var mLogName:String = "";
      
      private var mInitialized:Boolean = false;
      
      private var mLogLevel:Number = 0;
      
      private var mLogEntries:Array;
      
      public function Log()
      {
         super();
      }
      
      public static function getName() : String
      {
         return getInstance().getName();
      }
      
      public static function hasEventListener(param1:String) : Boolean
      {
         return getInstance().hasEventListener(param1);
      }
      
      public static function warn(param1:*) : void
      {
         getInstance().log(2,param1);
      }
      
      public static function error(param1:*) : void
      {
         getInstance().log(1,param1);
      }
      
      public static function isDebug() : Boolean
      {
         return getInstance().isDebug();
      }
      
      public static function removeEventListener(param1:String, param2:Function, param3:Boolean = false) : void
      {
         getInstance().removeEventListener(param1,param2,param3);
      }
      
      public static function getInstance() : Log
      {
         if(gInstance == null)
         {
            gInstance = new Log();
            gInstance.init();
         }
         return gInstance;
      }
      
      public static function spam(param1:*) : void
      {
         getInstance().log(5,param1);
      }
      
      public static function debug(param1:*) : void
      {
         getInstance().log(4,param1);
      }
      
      public static function addEventListener(param1:String, param2:Function, param3:Boolean = false, param4:int = 0, param5:Boolean = false) : void
      {
         getInstance().addEventListener(param1,param2,param3,param4,param5);
      }
      
      public static function getLogLevel() : Number
      {
         return getInstance().mLogLevel;
      }
      
      public static function init() : void
      {
         getInstance().init();
      }
      
      public static function setName(param1:String) : void
      {
         getInstance().setName(param1);
      }
      
      public static function getErrorReport() : Array
      {
         return getInstance().getErrorReport();
      }
      
      public static function setLogLevel(param1:Number) : void
      {
         getInstance().setLogLevel(param1);
      }
      
      public static function info(param1:*) : void
      {
         getInstance().log(3,param1);
      }
      
      private function getName() : String
      {
         return mLogName;
      }
      
      public function getOSInfo() : String
      {
         return "OS: " + Capabilities.os + ", " + Capabilities.screenResolutionX + "x" + Capabilities.screenResolutionY + ", current version: " + Capabilities.version;
      }
      
      private function isDebug() : Boolean
      {
         return mLogLevel >= 4;
      }
      
      private function setName(param1:String) : void
      {
         mLogName = param1;
      }
      
      public function addLogEntry(param1:String, param2:*) : void
      {
         if(param2 is String)
         {
            if(mLogEntries.length > MAX_LOG_ENTRIES)
            {
               mLogEntries.splice(0,1);
            }
            mLogEntries.push({
               "type":param1,
               "time":getTimestamp(),
               "text":sanitize(param2)
            });
         }
      }
      
      private function init() : void
      {
         if(!mInitialized)
         {
            mInitialized = true;
            this.addEventListener(LogEvent.DEBUG,onDebugMessage);
            this.addEventListener(LogEvent.INFO,onInfoMessage);
            this.addEventListener(LogEvent.WARN,onWarnMessage);
            this.addEventListener(LogEvent.ERROR,onErrorMessage);
            this.addEventListener(LogEvent.SPAM,onSpamMessage);
            mLogEntries = new Array();
            Log.info("kongregate log initialized.");
            Log.info(getOSInfo());
         }
      }
      
      private function onWarnMessage(param1:LogEvent) : void
      {
         logToFirebug("warn",param1.text);
      }
      
      private function log(param1:int, param2:*) : void
      {
         var _loc3_:String = null;
         if(param1 < LEVELS_MAP.Spam)
         {
            addLogEntry(_loc3_,param2);
         }
         if(mLogLevel >= param1)
         {
            _loc3_ = getLevelString(param1);
            dispatch(_loc3_,param2);
            trace("[" + _loc3_ + "] " + param2);
         }
      }
      
      private function onDebugMessage(param1:LogEvent) : void
      {
         logToFirebug("log",param1.text);
      }
      
      private function onErrorMessage(param1:LogEvent) : void
      {
         var _loc2_:* = param1.text;
         if(_loc2_ is Error)
         {
            _loc2_ = _loc2_.message + "\n" + _loc2_.getStackTrace();
            logToFirebug("warn",_loc2_);
         }
         else
         {
            _loc2_ = param1.text;
            logToFirebug("warn",_loc2_);
         }
      }
      
      private function onSpamMessage(param1:LogEvent) : void
      {
         logToFirebug("log",param1.text);
      }
      
      private function getTimestamp() : String
      {
         var _loc1_:Date = new Date();
         return _loc1_.toString().split("GMT")[0];
      }
      
      private function onInfoMessage(param1:LogEvent) : void
      {
         logToFirebug("info",param1.text);
      }
      
      public function setLogLevel(param1:Number) : void
      {
         mLogLevel = param1;
      }
      
      private function getErrorReport() : Array
      {
         return mLogEntries;
      }
      
      private function sanitize(param1:String) : String
      {
         return param1.split("<").join("&lt;");
      }
      
      private function logToFirebug(param1:String, param2:*) : void
      {
         var json:String = null;
         var f:String = null;
         var type:String = param1;
         var text:* = param2;
         var oldMarshalExceptions:Boolean = ExternalInterface.marshallExceptions;
         ExternalInterface.marshallExceptions = true;
         try
         {
            if(text is String)
            {
               text = text.replace(/\\/g,"\\\\");
            }
            else
            {
               try
               {
                  json = escape(com.adobe.serialization.json.JSON.encode(text));
                  f = "function(s,l){try{console[l].apply(console, [JSON.parse(unescape(s))]);}catch(e){}}";
                  ExternalInterface.call(f,json,type);
                  §§goto(addr0091);
               }
               catch(e:Error)
               {
                  ExternalInterface.call("window.console.error","Error while logging: failed to convert to JSON");
               }
               ExternalInterface.marshallExceptions = oldMarshalExceptions;
               switch(§§pop())
               {
                  case 0:
                     addr0091:
                     return;
                  case 1:
                  default:
                     §§goto(addr011b);
               }
            }
            ExternalInterface.call("window.console." + type,text);
         }
         catch(e:Error)
         {
         }
         finally
         {
            ExternalInterface.marshallExceptions = oldMarshalExceptions;
         }
         addr011b:
      }
      
      private function dispatch(param1:String, param2:*) : Boolean
      {
         if(mLogName != null && mLogName.length > 0)
         {
            if(param2 is String)
            {
               param2 = "[" + mLogName + "] " + param2;
            }
         }
         return dispatchEvent(new LogEvent(param1,param2));
      }
      
      private function getLevelString(param1:int) : String
      {
         return LEVELS[param1 - 1];
      }
   }
}

