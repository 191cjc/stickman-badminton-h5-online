package com.kongregate.as3.client.services
{
   public interface IHighScoreServices
   {
      
      function submit(param1:Number, param2:String = null) : void;
      
      function setMode(param1:String) : void;
      
      function requestList(param1:Function) : void;
   }
}

