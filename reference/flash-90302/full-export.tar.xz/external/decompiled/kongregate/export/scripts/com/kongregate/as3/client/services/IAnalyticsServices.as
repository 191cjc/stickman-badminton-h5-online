package com.kongregate.as3.client.services
{
   public interface IAnalyticsServices
   {
      
      function setCommonProperties(param1:Object) : void;
      
      function setAutomaticVariablesListener(param1:Function) : void;
      
      function startPurchase(param1:*, param2:Object) : void;
      
      function getAutoBoolProperty(param1:String) : Boolean;
      
      function updateCommonProperties() : void;
      
      function setCommonPropsCallback(param1:Function) : void;
      
      function start() : void;
      
      function getAutoDoubleProperty(param1:String) : Number;
      
      function getAutoPropertiesJSON() : String;
      
      function getAutoLongLongProperty(param1:String) : Number;
      
      function addFilterType(param1:String) : void;
      
      function getAutoUTCProperty(param1:String) : String;
      
      function getAutoLongProperty(param1:String) : Number;
      
      function addEvent(param1:String, param2:Object) : void;
      
      function getAutoStringProperty(param1:String) : String;
      
      function finishPurchase(param1:String, param2:String, param3:Object) : void;
      
      function getAutoIntProperty(param1:String) : int;
   }
}

