package com.kongregate.as3.client.services
{
   public interface IStatServices
   {
      
      function gameStart() : void;
      
      function submitArray(param1:Array) : void;
      
      function gameMute() : void;
      
      function gameUnmute() : void;
      
      function gamePause() : void;
      
      function submit(param1:String, param2:Number) : void;
      
      function gameEnd() : void;
      
      function gameUnpause() : void;
      
      function gameBreak() : void;
   }
}

