package com.kongregate.as3.client.services
{
   import com.kongregate.as3.common.util.Log;
   
   public class SharedContentServiceShadow extends AbstractShadowService implements ISharedContentServices
   {
      
      public function SharedContentServiceShadow()
      {
         super();
      }
      
      public function addLoadListener(param1:String, param2:Function) : void
      {
         Log.info("SharedContentService#addLoadListener - contentType:" + param1);
      }
      
      public function save(param1:String, param2:String, param3:Function, param4:* = null, param5:String = null) : void
      {
         Log.info("SharedContentService#save - contentType:" + param1 + ", value:" + param2 + ", label:" + param5);
         param3({"success":false});
      }
      
      public function browse(param1:String, param2:String = null, param3:String = null) : void
      {
         Log.info("SharedContentService#browse - contentType:" + param1 + ", sortOrder: " + param2.toString() + ", label: " + param3);
      }
   }
}

