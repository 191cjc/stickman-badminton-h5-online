package com.kongregate.as3.client.services
{
   import com.kongregate.as3.common.util.Log;
   
   public class KongregateServiceShadow extends AbstractShadowService implements IKongregateServices
   {
      
      public function KongregateServiceShadow()
      {
         super();
      }
      
      public function setConnection(param1:*) : void
      {
         Log.info("Connection set");
      }
      
      public function getName() : String
      {
         alert("IKongregateServices","getName");
         return "Guest";
      }
      
      public function getGameAuthToken() : String
      {
         return "";
      }
      
      public function connect(param1:Number = -1) : Boolean
      {
         alert("IKongregateServices","connect",arguments);
         return true;
      }
      
      public function getPlayerInfo(param1:Function) : void
      {
         alert("IKongregateServices","getPlayerInfo");
         param1(new Object());
      }
      
      public function isGuest() : Boolean
      {
         return true;
      }
      
      public function getUsername() : String
      {
         return "Guest";
      }
      
      public function setMultiplayerConnection(param1:String, param2:*, param3:Object) : void
      {
         alert("Multiplayer connection set","setMultiplayerConnection");
      }
      
      public function showSignInBox() : void
      {
         alert("KongregateServices","showSignInBox");
      }
      
      public function connectExternal(param1:Object = null) : Boolean
      {
         alert("IKongregateServices","connectExternal",arguments);
         return true;
      }
   }
}

