package com.kongregate.as3.client.services
{
   public class MicrotransactionServiceShadow extends AbstractShadowService implements IMicrotransactionServices
   {
      
      public function MicrotransactionServiceShadow()
      {
         super();
      }
      
      public function requestItemList(param1:Array, param2:Function) : void
      {
         alert("IMicrotransactionServices","requestItemList",arguments);
      }
      
      public function purchaseItemsRemote(param1:String, param2:Function) : void
      {
         alert("IMicrotransactionServices","purchaseItemsRemote",arguments);
      }
      
      public function showIncentivizedAd() : void
      {
         alert("IMicrotransactionServices","showIncentivizedAd",arguments);
      }
      
      public function showKredPurchaseDialog(param1:String) : void
      {
         alert("IMicrotransactionServices","showKredPurchaseDialog",arguments);
      }
      
      public function requestUserItemList(param1:String, param2:Function) : void
      {
         alert("IMicrotransactionServices","requestUserItemList",arguments);
      }
      
      public function useItemInstance(param1:Number, param2:Function) : void
      {
         alert("IMicrotransactionServices","useItemInstance",arguments);
      }
      
      public function initializeIncentivizedAds() : void
      {
         alert("IMicrotransactionServices","initializeIncentivizedAds",arguments);
      }
      
      public function purchaseItems(param1:Array, param2:Function) : void
      {
         alert("IMicrotransactionServices","purchaseItems",arguments);
      }
   }
}

