package com.kongregate.as3.client.services
{
   public class ChatServiceShadow extends AbstractShadowService implements IChatServices
   {
      
      public function ChatServiceShadow()
      {
         super();
      }
      
      public function removeCanvasObject(param1:String) : void
      {
         alert("IChatServices","removeCanvasObject",arguments);
      }
      
      public function positionCanvasObject(param1:String, param2:Object) : void
      {
         alert("IChatServices","positionCanvasObject",arguments);
      }
      
      public function displayCanvasText(param1:String, param2:String, param3:Object, param4:Object) : void
      {
         alert("IChatServices","displayCanvasText",arguments);
      }
      
      public function displayCanvasImage(param1:String, param2:String, param3:Object) : void
      {
         alert("IChatServices","displayCanvasImage",arguments);
      }
      
      public function displayMessage(param1:String, param2:String) : void
      {
         alert("IChatServices","displayMessage",arguments);
      }
      
      public function showSignInBox() : void
      {
         alert("IChatServices","showSignInBox",arguments);
      }
      
      public function drawCanvasObject(param1:String, param2:Array) : void
      {
         alert("IChatServices","drawCanvasObject",arguments);
      }
      
      public function showTab(param1:String, param2:String, param3:Object = null) : void
      {
         alert("IChatServices","showTab",arguments);
      }
      
      public function clearMessages() : void
      {
         alert("IChatServices","clearMessages",arguments);
      }
      
      public function closeTab() : void
      {
         alert("IChatServices","closeTab",arguments);
      }
      
      public function getCanvasSize() : Object
      {
         alert("IChatServices","getCanvasSize",arguments);
         return {
            "width":0,
            "height":0
         };
      }
   }
}

