package com.kongregate.as3.client
{
   import com.kongregate.as3.client.services.IHighScoreServices;
   import com.kongregate.as3.client.services.IStatServices;
   import com.kongregate.as3.client.services.IUserServices;
   
   public interface IGameServices
   {
      
      function get scores() : IHighScoreServices;
      
      function get loaded() : Boolean;
      
      function get connected() : Boolean;
      
      function get user() : IUserServices;
      
      function get stats() : IStatServices;
   }
}

