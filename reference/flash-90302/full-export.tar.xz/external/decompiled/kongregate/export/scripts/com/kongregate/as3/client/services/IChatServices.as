package com.kongregate.as3.client.services
{
   public interface IChatServices
   {
      
      function positionCanvasObject(param1:String, param2:Object) : void;
      
      function displayCanvasImage(param1:String, param2:String, param3:Object) : void;
      
      function removeCanvasObject(param1:String) : void;
      
      function displayMessage(param1:String, param2:String) : void;
      
      function displayCanvasText(param1:String, param2:String, param3:Object, param4:Object) : void;
      
      function showSignInBox() : void;
      
      function addEventListener(param1:String, param2:Function, param3:Boolean = false, param4:int = 0, param5:Boolean = false) : void;
      
      function getCanvasSize() : Object;
      
      function showTab(param1:String, param2:String, param3:Object = null) : void;
      
      function clearMessages() : void;
      
      function drawCanvasObject(param1:String, param2:Array) : void;
      
      function closeTab() : void;
   }
}

