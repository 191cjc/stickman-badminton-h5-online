package
{
   import com.kongregate.as3.client.APIBootstrapShadow;
   import flash.system.Security;
   
   [SWF(width="500", height="375", backgroundColor="#869ca7", frameRate="24")]
   public class as3_api_local extends APIBootstrapShadow
   {
      
      public function as3_api_local()
      {
         Security.allowDomain("*");
         super();
      }
   }
}

