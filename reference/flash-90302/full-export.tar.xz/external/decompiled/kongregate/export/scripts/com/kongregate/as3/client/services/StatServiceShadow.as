package com.kongregate.as3.client.services
{
   public class StatServiceShadow extends AbstractShadowService implements IStatServices
   {
      
      public function StatServiceShadow()
      {
         super();
      }
      
      public function submitArray(param1:Array) : void
      {
         alert("IStatServices","submitArray",arguments);
      }
      
      public function gameMute() : void
      {
         alert("IStatServices","gameMute",arguments);
      }
      
      public function gamePause() : void
      {
         alert("IStatServices","gamePause",arguments);
      }
      
      public function gameUnmute() : void
      {
         alert("IStatServices","gameUnmute",arguments);
      }
      
      public function gameEnd() : void
      {
         alert("IStatServices","gameEnd",arguments);
      }
      
      public function gameStart() : void
      {
         alert("IStatServices","gameStart",arguments);
      }
      
      public function gameUnpause() : void
      {
         alert("IStatServices","gameUnpause",arguments);
      }
      
      public function gameBreak() : void
      {
         alert("IStatServices","gameBreak",arguments);
      }
      
      public function submit(param1:String, param2:Number) : void
      {
         alert("IStatServices","submitStat",arguments);
      }
   }
}

