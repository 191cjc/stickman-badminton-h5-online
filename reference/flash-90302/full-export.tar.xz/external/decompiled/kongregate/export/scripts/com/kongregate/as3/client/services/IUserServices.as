package com.kongregate.as3.client.services
{
   public interface IUserServices
   {
      
      function getName() : String;
      
      function getSessionStamp() : String;
      
      function getPlayerInfo(param1:Function) : void;
   }
}

