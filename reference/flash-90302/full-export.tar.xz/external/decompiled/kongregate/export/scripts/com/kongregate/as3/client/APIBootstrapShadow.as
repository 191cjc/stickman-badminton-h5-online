package com.kongregate.as3.client
{
   import com.kongregate.as3.client.services.AnalyticsServiceShadow;
   import com.kongregate.as3.client.services.ChatServiceShadow;
   import com.kongregate.as3.client.services.HighScoreServiceShadow;
   import com.kongregate.as3.client.services.IAnalyticsServices;
   import com.kongregate.as3.client.services.IChatServices;
   import com.kongregate.as3.client.services.IHighScoreServices;
   import com.kongregate.as3.client.services.IKongregateServices;
   import com.kongregate.as3.client.services.IMicrotransactionServices;
   import com.kongregate.as3.client.services.ISharedContentServices;
   import com.kongregate.as3.client.services.IStatServices;
   import com.kongregate.as3.client.services.IUserServices;
   import com.kongregate.as3.client.services.KongregateServiceShadow;
   import com.kongregate.as3.client.services.MicrotransactionServiceShadow;
   import com.kongregate.as3.client.services.SharedContentServiceShadow;
   import com.kongregate.as3.client.services.StatServiceShadow;
   import com.kongregate.as3.client.services.UserServiceShadow;
   import flash.display.Sprite;
   import flash.display.Stage;
   import flash.events.Event;
   import flash.system.Security;
   
   public class APIBootstrapShadow extends Sprite implements IGameServices
   {
      
      private static var _statServices:StatServiceShadow;
      
      private static var _analyticsServices:IAnalyticsServices;
      
      private static var _userServices:IUserServices;
      
      private static var _scoreServices:IHighScoreServices;
      
      private static var _sharedContentServices:ISharedContentServices;
      
      private static var _chatServices:IChatServices;
      
      private static var _kongregateServices:IKongregateServices;
      
      private static var _mtxServices:IMicrotransactionServices;
      
      public function APIBootstrapShadow()
      {
         super();
         Security.allowDomain("*");
         this.addEventListener(Event.ADDED_TO_STAGE,init,false,0,true);
      }
      
      public function get scores() : IHighScoreServices
      {
         return _scoreServices;
      }
      
      public function get loaded() : Boolean
      {
         return true;
      }
      
      public function get stats() : IStatServices
      {
         return _statServices;
      }
      
      public function get connected() : Boolean
      {
         return true;
      }
      
      public function get analytics() : IAnalyticsServices
      {
         return _analyticsServices;
      }
      
      public function init(param1:Event = null, param2:Stage = null) : void
      {
         trace("Alert: Kongregate API shadow services loaded due to local testing. API will load when the game is uploaded.");
         _kongregateServices = new KongregateServiceShadow();
         _scoreServices = new HighScoreServiceShadow();
         _sharedContentServices = new SharedContentServiceShadow();
         _statServices = new StatServiceShadow();
         _userServices = new UserServiceShadow();
         _mtxServices = new MicrotransactionServiceShadow();
         _chatServices = new ChatServiceShadow();
         _analyticsServices = new AnalyticsServiceShadow();
      }
      
      public function get mtx() : IMicrotransactionServices
      {
         return _mtxServices;
      }
      
      public function get user() : IUserServices
      {
         return _userServices;
      }
      
      public function get sharedContent() : ISharedContentServices
      {
         return _sharedContentServices;
      }
      
      public function get chat() : IChatServices
      {
         return _chatServices;
      }
      
      public function get events() : Class
      {
         return null;
      }
      
      public function get services() : IKongregateServices
      {
         return _kongregateServices;
      }
   }
}

