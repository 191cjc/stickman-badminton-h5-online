package cpmstar
{
   import flash.display.*;
   import flash.events.*;
   import flash.external.*;
   import flash.filters.*;
   import flash.media.*;
   import flash.net.*;
   import flash.system.*;
   import flash.text.*;
   import flash.ui.Mouse;
   import flash.utils.*;
   
   [SWF(width="800", height="600", backgroundColor="#ffffff", frameRate="30")]
   public class AdView extends Sprite
   {
      
      private static const LOG_IDENTIFIER:String = "CPMSTAR:AdViewAs3:";
      
      internal var adblockChecked:Boolean = false;
      
      internal var bcLoader:URLLoader = new URLLoader();
      
      internal var urlLoader:URLLoader = new URLLoader();
      
      internal var ad_mc_parent:Sprite;
      
      internal var leaveBehindFlashUrl:String;
      
      internal var swfLoader:Loader;
      
      internal var pixelLoader:Loader = new Loader();
      
      internal var completed:Boolean;
      
      internal var added:Boolean;
      
      internal var cpmstarGameDesiredFrameRate:int;
      
      internal var cpmstarGameDesiredQuality:String;
      
      internal var cpmstarStage:Stage;
      
      internal var muteLeaveBehind:Boolean;
      
      internal var skipSeconds:Number = 100;
      
      internal var skipFraction:Number = 0.25;
      
      internal var toploaderswfversion:Number = -1;
      
      internal var lcName:String;
      
      internal var lc:LocalConnection;
      
      internal var overlay:Sprite;
      
      internal var progressBar:Sprite;
      
      internal var progressBarForeground:Sprite;
      
      internal var overlay_ad_mc_parent:Sprite;
      
      internal var overlayLoader:Loader;
      
      internal var overlayRemoved:Boolean = false;
      
      internal var skipButton:Sprite;
      
      internal var overlayShown:Boolean;
      
      internal var overlayAddedToStage:Boolean = false;
      
      internal var blockChildAds:Boolean = true;
      
      internal var childAdUrl:String = ".cpmstar.com/cached/swf/watermark10.swf";
      
      internal var cdnHttpServer:String = "http://cdn";
      
      internal var cdnSSLServer:String = "https://ssl.cdne";
      
      internal var childAd:Sprite;
      
      internal var childAdLoader:Loader;
      
      internal var startVolume:Number;
      
      internal var adDuration:int = 0;
      
      internal var coverStartTime:int;
      
      internal var progressBarStartTime:int;
      
      internal var progressBarEnterFrameHandler:Function;
      
      internal var overlayStartTime:int;
      
      internal var skipButtonStartTime:int;
      
      internal var layout:String;
      
      internal var companionHtml:String;
      
      internal const serverHost:String = "server.cpmstar.com";
      
      internal const progressBarOutlineColor:Number = 16777215;
      
      internal const progressBarBackgroundColor:Number = 4194368;
      
      internal const progressBarForegroundColor:Number = 9474303;
      
      internal const progressBarDurationColor:Number = 12632319;
      
      internal const HEADER_HEIGHT:Number = 25;
      
      internal const FOOTER_HEIGHT:Number = 35;
      
      internal var containerWidth:Number;
      
      internal var containerHeight:Number;
      
      internal var srcUrl:String = "undefined";
      
      internal var cpmstar_url:String;
      
      internal var campaignID:int = 0;
      
      internal var AdEvent:Class;
      
      internal var skipped:Boolean;
      
      internal var hasLeaveBehind:Boolean;
      
      internal var interstitial:int = 0;
      
      internal var clickAction:String;
      
      internal var macros:Object;
      
      internal var top:DisplayObject;
      
      internal var parameters:Object;
      
      internal var overlayAttempts:int = 0;
      
      internal var parentParams:Object;
      
      internal var isMute:Boolean = false;
      
      internal var toggleVolume:Boolean = false;
      
      internal var hasScriptAccess:Boolean = false;
      
      internal var px_cr:String;
      
      internal var passbackError:String;
      
      private var scaleFactor:Number;
      
      private var videoWidth:Number;
      
      private var videoHeight:Number;
      
      private var totalWidth:Number;
      
      private var totalHeight:Number;
      
      public function AdView()
      {
         super();
         log("AdView Constructor");
         Security.allowDomain("cdn.cpmstar.com");
         if(stage)
         {
            addEventListener(Event.ENTER_FRAME,init);
         }
         else
         {
            addEventListener(Event.ADDED_TO_STAGE,preinit);
         }
      }
      
      private static function log(param1:String) : void
      {
      }
      
      private function preinit(param1:Event = null) : void
      {
         removeEventListener(Event.ADDED_TO_STAGE,preinit);
         addEventListener(Event.ENTER_FRAME,init);
      }
      
      private function init(param1:Event = null) : void
      {
         var scaleMode:String = null;
         var i:String = null;
         var testVar:int = 0;
         var allowOverlay:Boolean = false;
         var overlayTime:int = 0;
         var allowBuggyAs3Ads:Boolean = false;
         var spaceIndex:int = 0;
         var versionParts:Array = null;
         var e:Event = param1;
         log("init()");
         removeEventListener(Event.ENTER_FRAME,init);
         try
         {
            AdEvent = parent.loaderInfo.applicationDomain.getDefinition("cpmstar.AdEvent") as Class;
         }
         catch(e:Error)
         {
         }
         if(AdEvent)
         {
            sendEventToContainer(new AdEvent(AdEvent.INIT,hasEventListener));
         }
         top = this;
         try
         {
            while(top.parent != null)
            {
               if(top.root != null && top.root is Stage)
               {
                  break;
               }
               if(top.parent is Stage)
               {
                  break;
               }
               if(top.parent.root == top)
               {
                  break;
               }
               top = top.parent;
            }
         }
         catch(e:Error)
         {
         }
         try
         {
            top.addEventListener(MouseEvent.MOUSE_OVER,showCursor);
         }
         catch(e:Error)
         {
         }
         try
         {
            scaleMode = stage.scaleMode;
         }
         catch(e:Error)
         {
         }
         if(scaleMode == StageScaleMode.NO_SCALE)
         {
            try
            {
               containerWidth = int(stage.stageWidth);
               containerHeight = int(stage.stageHeight);
            }
            catch(e:Error)
            {
            }
         }
         else
         {
            try
            {
               containerWidth = top.loaderInfo.width;
               containerHeight = top.loaderInfo.height;
            }
            catch(e:Error)
            {
               try
               {
                  containerWidth = int(Math.min(stage.width,stage.stageWidth));
                  containerHeight = int(Math.min(stage.height,stage.stageHeight));
               }
               catch(e:Error)
               {
                  try
                  {
                     containerWidth = int(stage.stageWidth);
                     containerHeight = int(stage.stageHeight);
                  }
                  catch(e:Error)
                  {
                     containerWidth = 0;
                     containerHeight = 0;
                  }
               }
            }
         }
         if(containerWidth <= 0)
         {
            containerWidth = 550;
         }
         if(containerHeight <= 0)
         {
            containerHeight = 440;
         }
         startVolume = SoundMixer.soundTransform.volume;
         try
         {
            if(top.parent != null && top.parent.loaderInfo != null && top.parent.loaderInfo.parameters != null)
            {
               parentParams = top.parent.loaderInfo.parameters;
               for(i in parentParams)
               {
                  if(i == "type" && parentParams[i] == "floor")
                  {
                     toggleVolume = true;
                  }
                  else if(i == "volume")
                  {
                     startVolume = 0;
                     if(!isNaN(parentParams[i]))
                     {
                        startVolume = Number(parentParams[i]);
                     }
                     SoundMixer.soundTransform = new SoundTransform(startVolume);
                  }
               }
            }
         }
         catch(err:Error)
         {
            log("Failed to initialize sound.");
         }
         try
         {
            toploaderswfversion = top.loaderInfo.swfVersion;
         }
         catch(e:Error)
         {
            toploaderswfversion = -1;
         }
         isMute = SoundMixer.soundTransform.volume == 0;
         try
         {
            ExternalInterface.call("console.log","hasScriptAccess");
            hasScriptAccess = true;
         }
         catch(err:Error)
         {
         }
         urlLoader.addEventListener(Event.COMPLETE,completeHandler);
         urlLoader.addEventListener(IOErrorEvent.IO_ERROR,errorHandler);
         urlLoader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,errorHandler);
         parameters = loaderInfo.parameters;
         if(Boolean(clickAction) && macros is Object)
         {
            log("init(): macros passed in");
            loadAd();
         }
         else if(Boolean(parameters.contentspotid) || Boolean(parameters.poolid) || Boolean(parameters["amp;poolid"]))
         {
            log("init(): found poolid or contentspotid");
            allowOverlay = true;
            overlayTime = 0;
            try
            {
               srcUrl = top.root.loaderInfo.loaderURL;
            }
            catch(e:Error)
            {
            }
            try
            {
               testVar = stage.width;
            }
            catch(e:Error)
            {
               log("init: attempted to access stage, but got this error, so no overlays: " + e);
               allowOverlay = false;
               blockChildAds = true;
            }
            if(parameters.contentspotid != null)
            {
               cpmstar_url = serverUrl + "viewcontent.aspx?xml=1&b=0&contentspotid=" + parameters.contentspotid + "&maxwidth=" + int(containerWidth) + "&maxheight=" + (int(containerHeight) - HEADER_HEIGHT - FOOTER_HEIGHT) + "&srcurl=" + encodeURIComponent(srcUrl) + "&fv=" + toploaderswfversion + "&allowscript=" + (hasScriptAccess ? 1 : 0);
            }
            else
            {
               if(parameters["amp;poolid"] != null)
               {
                  parameters.poolid = parameters["amp;poolid"];
               }
               if(parameters["amp;subpoolid"] != null)
               {
                  parameters.subpoolid = parameters["amp;subpoolid"];
               }
               if(parameters.poolid == null || parameters.subpoolid == null)
               {
                  return;
               }
               cpmstar_url = serverUrl + "view.aspx?xml=1&b=0&poolid=" + parameters.poolid + "&subpoolid=" + parameters.subpoolid + "&maxwidth=" + int(containerWidth) + "&maxheight=" + (int(containerHeight) - HEADER_HEIGHT - FOOTER_HEIGHT) + "&srcurl=" + encodeURIComponent(srcUrl) + "&fv=" + toploaderswfversion + "&allowscript=" + (hasScriptAccess ? 1 : 0);
               if(parameters["amp;blockoverlays"] != null)
               {
                  parameters.blockoverlays = parameters["amp;blockoverlays"];
               }
               if(parameters.blockoverlays == "1")
               {
                  cpmstar_url += "&blockoverlays=1";
               }
               if(parameters["amp;blockchildads"] != null)
               {
                  parameters.blockchildads = parameters["amp;blockchildads"];
               }
               if(parameters.blockchildads == "1")
               {
                  cpmstar_url += "&blockchildads=1";
               }
            }
            try
            {
               if(top["_cpmstar_lastshown"] != null)
               {
                  interstitial = 1 + int(new Date().time / 1000 - top["_cpmstar_lastshown"]);
               }
            }
            catch(e:Error)
            {
            }
            try
            {
               if(top["_cpmstar_lastoverlay"] != null)
               {
                  overlayTime = 1 + int(new Date().time / 1000 - top["_cpmstar_lastoverlay"]);
               }
            }
            catch(e:Error)
            {
            }
            if(!allowOverlay)
            {
               cpmstar_url += "&adtypeid=14";
            }
            cpmstar_url += "&noadtypeid=3,24";
            if(interstitial != 0)
            {
               overlayTime = 1;
            }
            cpmstar_url += "&interstitial=" + interstitial + "&overlaytime=" + overlayTime;
            allowBuggyAs3Ads = false;
            try
            {
               if(!Capabilities.isDebugger)
               {
                  allowBuggyAs3Ads = true;
               }
               else
               {
                  log("isDebugger");
                  spaceIndex = Capabilities.version.indexOf(" ");
                  if(spaceIndex != -1)
                  {
                     versionParts = Capabilities.version.substr(spaceIndex).split(",");
                     if(versionParts.length >= 2 && (Number(versionParts[0]) > 10 || Number(versionParts[0]) == 10 && Number(versionParts[1]) >= 1))
                     {
                        if(top.loaderInfo.swfVersion >= 10)
                        {
                           allowBuggyAs3Ads = true;
                           if(loaderInfo.hasOwnProperty("uncaughtErrorEvents"))
                           {
                              loaderInfo["uncaughtErrorEvents"].addEventListener("uncaughtError",function(param1:Event):void
                              {
                                 param1.preventDefault();
                              });
                              log("logging uncaughtErrorEvents");
                           }
                        }
                     }
                  }
               }
            }
            catch(e:Error)
            {
            }
            if(allowBuggyAs3Ads)
            {
               cpmstar_url += "&trapserrors=1";
            }
            log("init: first attempt = " + cpmstar_url);
            urlLoader.load(new URLRequest(cpmstar_url));
         }
         else if(Boolean(parameters.preview) && Boolean(parameters["campaignid"] != null) && parameters["creativeid"] != null)
         {
            cpmstar_url = (isHttps ? "https://" : "http://") + hostname() + "/tests/previewadserver/view.aspx?campaignid=" + parameters["campaignid"] + "&creativeid=" + parameters["creativeid"] + "&ingame=1";
            log("loading preview url: " + cpmstar_url);
            urlLoader.load(new URLRequest(cpmstar_url));
         }
         else
         {
            log("init(): no ad and not contentspotid/poolid");
            if(AdEvent)
            {
               sendEventToContainer(new AdEvent(AdEvent.NO_AD,hasLeaveBehind));
            }
            sendEventToContainer(new Event("CpmstarVideoAdError",true,false));
         }
         addEventListener(Event.REMOVED_FROM_STAGE,swfRemovedHandler);
         childAdUrl = (!isHttps ? cdnHttpServer : cdnSSLServer) + childAdUrl;
         try
         {
            top["_cpmstar_lastshown"] = new Date().time / 1000;
         }
         catch(e:Error)
         {
         }
      }
      
      private function showCursor(param1:Event) : void
      {
         log("showCursor()");
         Mouse.show();
      }
      
      private function get isHttps() : Boolean
      {
         var _loc1_:String = null;
         var _loc2_:Boolean = false;
         try
         {
            _loc1_ = this.loaderInfo.url;
            if(_loc1_.indexOf("https") >= 0)
            {
               _loc2_ = true;
            }
         }
         catch(err:Error)
         {
         }
         return _loc2_;
      }
      
      public function get serverUrl() : String
      {
         return (isHttps ? "https://" : "http://") + serverHost + "/";
      }
      
      public function hostname() : String
      {
         var url:String = null;
         var testsPosition:Number = NaN;
         var hostPosition:Number = NaN;
         var rv:String = "gamestraffic.com";
         try
         {
            url = this.loaderInfo.url;
            testsPosition = url.indexOf("/tests/");
            hostPosition = url.indexOf("://") + 3;
            if(testsPosition > hostPosition)
            {
               rv = url.substring(hostPosition,testsPosition);
            }
         }
         catch(error:Error)
         {
         }
         return rv;
      }
      
      public function configure(param1:String, param2:Object, param3:String = "", param4:String = "") : void
      {
         this.clickAction = param1;
         this.macros = param2;
         this.passbackError = param3;
         this.px_cr = param4;
      }
      
      public function configureXml(param1:XML) : void
      {
         var _loc2_:XML = null;
         log("configureXml()");
         clickAction = null;
         macros = null;
         if(param1 == null || param1.creative[0] == null)
         {
            log("configureXml: no ad found");
            if(AdEvent)
            {
               sendEventToContainer(new AdEvent(AdEvent.NO_AD,hasLeaveBehind));
            }
            sendEventToContainer(new Event("CpmstarVideoAdError",true,false));
            return;
         }
         clickAction = param1.creative[0].click[0];
         passbackError = param1.creative[0].pb_err[0];
         px_cr = param1.creative[0].px_cr[0];
         log("passbackerror: " + passbackError);
         macros = {};
         for each(_loc2_ in param1.creative[0].macros[0].macro)
         {
            log("configureXml: macros=" + _loc2_.@name[0] + " - " + _loc2_.@value[0]);
            macros[String(_loc2_.@name[0]).toLowerCase()] = _loc2_.@value[0];
         }
         log("configureXml: clickAction=" + clickAction);
         log("configureXml: macros=" + macros);
      }
      
      private function completeHandler(param1:Event) : void
      {
         log("completeHandler()");
         checkAdBlock();
         var _loc2_:URLLoader = URLLoader(param1.target);
         configureXml(new XML(_loc2_.data));
         loadAd();
      }
      
      private function loadAd() : void
      {
         var pixelUrls:Array;
         var tmpBlockChildAdsMacroVisted:Boolean;
         var pixelNumber:int;
         var flashUrl:String = null;
         var videoUrl:String = null;
         var flashVars:String = null;
         var referrer:String = null;
         var as3FlashUrl:String = null;
         var overlayUrl:String = null;
         var overlayVars:String = null;
         var i:String = null;
         var campaignIDIdentifier:String = null;
         var campaignIDIndex:Number = NaN;
         var campaignIDEndIndex:Number = NaN;
         var pixelUrl:String = null;
         var loader:URLLoader = null;
         var lcClient:Object = null;
         log("loadAd()");
         if(!clickAction || !macros)
         {
            log("loadAd: no ad found!");
            if(AdEvent)
            {
               sendEventToContainer(new AdEvent(AdEvent.NO_AD,hasLeaveBehind));
            }
            sendEventToContainer(new Event("CpmstarVideoAdError",true,false));
            return;
         }
         pixelUrls = new Array();
         if(clickAction != null)
         {
            campaignIDIdentifier = "campaignid=";
            campaignIDIndex = clickAction.indexOf(campaignIDIdentifier);
            if(campaignIDIndex >= 0)
            {
               campaignIDEndIndex = clickAction.indexOf("&",campaignIDIndex);
               if(campaignIDEndIndex < 0)
               {
                  campaignIDEndIndex = clickAction.length;
               }
               campaignID = Number(clickAction.substring(campaignIDIndex + campaignIDIdentifier.length,campaignIDEndIndex));
            }
         }
         log("loadAd: start macro parsing");
         tmpBlockChildAdsMacroVisted = false;
         for(i in macros)
         {
            switch(i)
            {
               case "flashurl":
                  flashUrl = macros[i];
                  break;
               case "videourl":
                  videoUrl = macros[i];
                  break;
               case "flashvars":
                  flashVars = macros[i];
                  break;
               case "referrer":
                  referrer = macros[i];
                  break;
               case "as3flashurl":
                  as3FlashUrl = macros[i];
                  break;
               case "blockchildads":
                  blockChildAds = Boolean(macros[i]);
                  tmpBlockChildAdsMacroVisted = true;
                  break;
               case "overlayurl":
                  overlayUrl = macros[i];
                  break;
               case "layout":
                  layout = macros[i];
                  break;
               case "muteleavebehind":
                  muteLeaveBehind = macros[i] == "true";
                  break;
               case "ov_skipseconds":
                  skipSeconds = Number(macros[i]);
                  break;
               case "ov_skipfraction":
                  skipFraction = Number(macros[i]);
                  break;
               default:
                  if(i.indexOf("pixelurl") == 0)
                  {
                     pixelUrls.push(macros[i]);
                  }
                  if(i.indexOf("ov_") == 0)
                  {
                     if(overlayVars == null)
                     {
                        overlayVars = i + "=" + encodeURIComponent(macros[i]);
                     }
                     else
                     {
                        overlayVars += "&" + i + "=" + encodeURIComponent(macros[i]);
                     }
                  }
            }
         }
         log("loadAd: done macro parsing");
         if(!tmpBlockChildAdsMacroVisted)
         {
            blockChildAds = false;
         }
         if(ad_mc_parent == null)
         {
            ad_mc_parent = new Sprite();
            addChild(ad_mc_parent);
         }
         leaveBehindFlashUrl = flashUrl;
         if(as3FlashUrl != null)
         {
            leaveBehindFlashUrl = as3FlashUrl;
         }
         if(leaveBehindFlashUrl != null)
         {
            if(clickAction != null)
            {
               leaveBehindFlashUrl += leaveBehindFlashUrl.indexOf("?") == -1 ? "?" : "&";
               leaveBehindFlashUrl += "clickTAG=" + encodeURIComponent(clickAction);
            }
            if(videoUrl != null)
            {
               leaveBehindFlashUrl += leaveBehindFlashUrl.indexOf("?") == -1 ? "?" : "&";
               leaveBehindFlashUrl += "videourl=" + encodeURIComponent(videoUrl);
            }
            if(flashVars != null)
            {
               leaveBehindFlashUrl += leaveBehindFlashUrl.indexOf("?") == -1 ? "?" : "&";
               leaveBehindFlashUrl += flashVars;
            }
            if(referrer != null)
            {
               leaveBehindFlashUrl += leaveBehindFlashUrl.indexOf("?") == -1 ? "?" : "&";
               leaveBehindFlashUrl += referrer + "=" + getReferrer();
            }
            hasLeaveBehind = true;
            if(overlayUrl == null)
            {
               showLeaveBehindFlashUrl();
            }
         }
         if(px_cr != null && px_cr != "")
         {
            pixelUrls.push(px_cr);
         }
         log("loadAd: loading CPMStar impression pixels");
         pixelNumber = 0;
         while(pixelNumber < pixelUrls.length)
         {
            pixelUrl = pixelUrls[pixelNumber];
            loader = new URLLoader();
            loader.addEventListener(IOErrorEvent.IO_ERROR,pixelErrorHandler);
            loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,pixelErrorHandler);
            loader.addEventListener(Event.COMPLETE,pixelLoadCompleteHandler);
            log("Pixel Loading: " + pixelUrl);
            loader.load(new URLRequest(serverUrl + "redirect.aspx?url=" + encodeURIComponent(pixelUrl)));
            pixelNumber++;
         }
         if(overlayUrl != null)
         {
            log("loadAd: overlayUrl != null");
            if(clickAction != null)
            {
               overlayUrl += overlayUrl.indexOf("?") == -1 ? "?" : "&";
               overlayUrl += "clickTAG=" + encodeURIComponent(clickAction);
            }
            if(overlayVars != null)
            {
               overlayUrl += overlayUrl.indexOf("?") == -1 ? "?" : "&";
               overlayUrl += overlayVars;
            }
            if(referrer != null)
            {
               overlayUrl += overlayUrl.indexOf("?") == -1 ? "?" : "&";
               overlayUrl += referrer + "=" + getReferrer();
            }
            lcName = "_cpmstar_" + int(Math.random() * 100000);
            overlayUrl += overlayUrl.indexOf("?") == -1 ? "?" : "&";
            overlayUrl += "lcname=" + lcName + "&width=" + int(containerWidth) + "&height=" + (int(containerHeight) - HEADER_HEIGHT - FOOTER_HEIGHT);
            lc = new LocalConnection();
            lc.allowDomain("*");
            lc.allowInsecureDomain("*");
            lc.connect(lcName);
            lc.addEventListener(StatusEvent.STATUS,function(param1:StatusEvent):void
            {
            });
            lcClient = new Object();
            lcClient.removeOverlay = removeOverlay;
            lcClient.showOverlayAd = showOverlayAd;
            lc.client = lcClient;
            addOverlay();
            if(overlayAddedToStage)
            {
               overlay_ad_mc_parent = new Sprite();
               overlay.addChild(overlay_ad_mc_parent);
               overlay_ad_mc_parent.visible = false;
               overlayLoader = new Loader();
               overlay_ad_mc_parent.addChild(overlayLoader);
               overlayLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,function(param1:Event):void
               {
                  log("overlayLoader IO_ERROR");
                  removeOverlay();
                  if(AdEvent)
                  {
                     sendEventToContainer(new AdEvent(AdEvent.ERROR,hasLeaveBehind));
                  }
                  sendEventToContainer(new Event("CpmstarVideoAdError",true,false));
               });
               overlayLoader.contentLoaderInfo.addEventListener(Event.COMPLETE,overlayLoadComplete);
               log("loading overlayUrl = " + overlayUrl);
               overlayLoader.load(new URLRequest(overlayUrl));
               try
               {
                  top["_cpmstar_lastoverlay"] = new Date().time / 1000;
               }
               catch(e:Error)
               {
               }
            }
         }
         if(!leaveBehindFlashUrl && !overlayUrl)
         {
            if(AdEvent)
            {
               sendEventToContainer(new AdEvent(AdEvent.NO_AD,hasLeaveBehind));
            }
            sendEventToContainer(new Event("CpmstarVideoAdError",true,false));
         }
         log("end loadAd()");
      }
      
      private function pixelLoadCompleteHandler(param1:Event) : void
      {
         log("Pixel Loaded.");
      }
      
      private function pixelErrorHandler(param1:Event) : void
      {
         param1.preventDefault();
         log("Pixel Loader Error: " + param1);
      }
      
      private function overlayLoadComplete(param1:Event) : void
      {
         var e:Event = param1;
         log("overlayLoadComplete()");
         try
         {
            lc.send(lcName + "_","srcUrl",srcUrl);
         }
         catch(e:Error)
         {
            log("overlayLoadComplete: lc.send error: " + e);
         }
         log("overlayLoadComplete: overlayLoader.visible=" + overlayLoader.visible);
      }
      
      private function addChildAd() : void
      {
         var _loc1_:String = null;
         if(childAd != null)
         {
            return;
         }
         if(blockChildAds)
         {
            return;
         }
         if(containerHeight < 140)
         {
            return;
         }
         if(interstitial > 0)
         {
            return;
         }
         if(parameters.contentspotid != null)
         {
            _loc1_ = childAdUrl + "?contentspotid=" + parameters.contentspotid;
         }
         else
         {
            if(!(parameters.poolid != null && parameters.subpoolid != null))
            {
               return;
            }
            _loc1_ = childAdUrl + "?poolid=" + parameters.poolid + "&subpoolid=" + parameters.subpoolid;
         }
         childAd = new Sprite();
         childAd.x = 0;
         childAd.y = containerHeight - 388;
         childAd.addEventListener(Event.ENTER_FRAME,childAdEnterFrameHandler);
         try
         {
            stage.addChild(childAd);
            childAdLoader = new Loader();
            childAdLoader.load(new URLRequest(_loc1_));
            childAd.addChild(childAdLoader);
         }
         catch(e:Error)
         {
         }
      }
      
      private function childAdEnterFrameHandler(param1:Event) : void
      {
         if(childAd == null || childAd.parent == null)
         {
            return;
         }
         var _loc2_:DisplayObjectContainer = childAd.parent;
         if(_loc2_.getChildIndex(childAd) < _loc2_.numChildren - 1)
         {
            _loc2_.addChildAt(childAd,_loc2_.numChildren);
         }
      }
      
      private function addOverlay() : void
      {
         var cover:Sprite;
         var barWidth:Number;
         var barHeight:Number;
         log("addOverlay()");
         overlay = new Sprite();
         overlayAddedToStage = false;
         if(stage != null)
         {
            try
            {
               stage.addChild(overlay);
               overlayAddedToStage = true;
            }
            catch(e:Error)
            {
               log("addOverlay: stage.addChild() error: " + e);
            }
         }
         cover = new Sprite();
         overlay.addChild(cover);
         cover.graphics.beginFill(0,0.9);
         cover.graphics.drawRect(0,0,2 * containerWidth,2 * containerHeight);
         cover.graphics.endFill();
         coverStartTime = getTimer();
         overlay.addEventListener(Event.ENTER_FRAME,overlayEnterFrameHandlerFadeOn);
         barWidth = containerWidth - 20;
         barHeight = 10;
         log("addOverlay: end. stage=" + stage + ", overlayAddedToStage=" + overlayAddedToStage + ", overlay.visible=" + overlay.visible);
      }
      
      private function showOverlayAd(param1:Number, param2:Number, param3:Number, param4:String) : void
      {
         var originalTotalWidth:Number;
         var originalTotalHeight:Number;
         var skipButtonParent:Sprite;
         var tf:TextField;
         var skipText:TextField;
         var barWidth:Number;
         var barHeight:Number;
         var mute:TextField = null;
         var videoWidth:Number = param1;
         var videoHeight:Number = param2;
         var duration:Number = param3;
         var companionHtml:String = param4;
         log("showOverlayAd()");
         if(!overlayAddedToStage)
         {
            log("!overlayAddedToStage");
            hasLeaveBehind = false;
            skip();
            return;
         }
         overlayShown = true;
         hasLeaveBehind = hasLeaveBehind || Boolean(companionHtml) && layout != "rightsidecompanion";
         totalWidth = videoWidth;
         totalHeight = videoHeight;
         if(layout == "rightsidecompanion")
         {
            totalWidth += 306;
            totalHeight = Math.max(totalHeight,250);
         }
         originalTotalWidth = totalWidth;
         originalTotalHeight = totalHeight;
         if(totalWidth > containerWidth)
         {
            totalHeight = totalHeight * containerWidth / totalWidth;
            totalWidth = containerWidth;
         }
         if(totalHeight > containerHeight - FOOTER_HEIGHT - HEADER_HEIGHT)
         {
            totalWidth = totalWidth * (containerHeight - FOOTER_HEIGHT - HEADER_HEIGHT) / totalHeight;
            totalHeight = containerHeight - FOOTER_HEIGHT - HEADER_HEIGHT;
         }
         scaleFactor = totalWidth / originalTotalWidth;
         this.videoWidth = videoWidth = videoWidth * scaleFactor;
         this.videoHeight = videoHeight = videoHeight * scaleFactor;
         overlayLoader.scaleX = scaleFactor;
         overlayLoader.scaleY = scaleFactor;
         overlay_ad_mc_parent.x = Math.round((containerWidth - totalWidth) / 2);
         overlay_ad_mc_parent.y = Math.round(HEADER_HEIGHT + (containerHeight - HEADER_HEIGHT - FOOTER_HEIGHT - totalHeight) / 2);
         overlay_ad_mc_parent.visible = true;
         skipButtonParent = overlay_ad_mc_parent;
         skipButtonParent.graphics.beginFill(6316128);
         skipButtonParent.graphics.drawRect(-3,-3,totalWidth + 6,totalHeight + 6);
         skipButtonParent.graphics.endFill();
         skipButtonParent.graphics.lineStyle(2,13684944,1,true,"normal","round","round");
         skipButtonParent.graphics.drawRect(-3,-3,totalWidth + 6,totalHeight + 6);
         tf = new TextField();
         skipButtonParent.addChild(tf);
         tf.x = (totalWidth - 200) / 2;
         tf.y = -25;
         tf.width = 200;
         tf.autoSize = TextFieldAutoSize.CENTER;
         tf.selectable = false;
         tf.setTextFormat(new TextFormat("_sans",11,16777215,null,null,null,null,null,TextFormatAlign.CENTER));
         tf.textColor = 16777215;
         tf.text = "Brought to you by...";
         tf.filters = [new GlowFilter(4210752,100,2,2,400,1)];
         skipButton = new Sprite();
         skipButtonParent.addChild(skipButton);
         skipButton.buttonMode = true;
         skipButton.useHandCursor = true;
         skipButton.visible = false;
         skipButton.alpha = 0;
         if(toggleVolume)
         {
            mute = new TextField();
            skipButtonParent.addChild(mute);
            mute.text = "Toggle Sound";
            mute.x = totalWidth - 150;
            mute.y = -25;
            mute.width = 200;
            mute.autoSize = TextFieldAutoSize.CENTER;
            mute.selectable = false;
            mute.setTextFormat(new TextFormat("_sans",11,16777215,null,null,null,null,null,TextFormatAlign.CENTER));
            mute.textColor = 16777215;
            mute.filters = [new GlowFilter(4210752,100,2,2,400,1)];
            mute.addEventListener(MouseEvent.CLICK,function(param1:Event):void
            {
               isMute = !isMute;
               if(isMute)
               {
                  SoundMixer.soundTransform = new SoundTransform(0);
               }
               else if(startVolume == 0)
               {
                  SoundMixer.soundTransform = new SoundTransform(0.65);
               }
               else
               {
                  SoundMixer.soundTransform = new SoundTransform(startVolume);
               }
            });
         }
         skipText = new TextField();
         skipButton.addChild(skipText);
         skipText.setTextFormat(new TextFormat("_sans",11,13684991,null,null,true,null,null,TextFormatAlign.RIGHT));
         skipText.textColor = 13684991;
         skipText.text = "Skip";
         skipText.selectable = false;
         skipText.filters = [new GlowFilter(4210752,100,2,2,400,1)];
         skipButton.x = Math.round(totalWidth + 3 - skipText.width);
         skipButton.y = Math.round(totalHeight + 5);
         skipButton.addEventListener(MouseEvent.CLICK,function(param1:Event):void
         {
            skip();
         });
         adDuration = duration * 1000;
         barWidth = containerWidth - 20;
         barHeight = 10;
         progressBar = new Sprite();
         progressBar.x = (containerWidth - barWidth) / 2;
         progressBar.y = containerHeight - barHeight - barHeight / 2;
         progressBar.graphics.beginFill(progressBarBackgroundColor);
         progressBar.graphics.drawRect(0,0,barWidth,barHeight);
         progressBar.graphics.endFill();
         progressBar.graphics.lineStyle(0,progressBarOutlineColor);
         progressBar.graphics.drawRect(0,0,barWidth,barHeight);
         overlay.addChild(progressBar);
         progressBarForeground = new Sprite();
         progressBar.addChild(progressBarForeground);
         progressBarForeground.graphics.beginFill(progressBarForegroundColor);
         progressBarForeground.graphics.drawRect(1,1,barWidth - 1,barHeight - 1);
         progressBarForeground.graphics.endFill();
         progressBarForeground.scaleX = 0;
         progressBarStartTime = getTimer();
         progressBar.removeEventListener(Event.ENTER_FRAME,progressBarEnterFrameHandler1);
         progressBar.addEventListener(Event.ENTER_FRAME,progressBarEnterFrameHandler2);
         this.companionHtml = companionHtml;
         if(layout == "rightsidecompanion")
         {
            showCompanion();
         }
         if(AdEvent)
         {
            sendEventToContainer(new AdEvent(AdEvent.OVERLAY_STARTED,hasLeaveBehind));
         }
         log("showOverlayAd: end");
      }
      
      private function skip() : void
      {
         try
         {
            lc.send(lcName + "_","skip");
         }
         catch(e:Error)
         {
         }
         skipped = true;
         log("skipped");
         removeOverlay();
         if(AdEvent)
         {
            sendEventToContainer(new AdEvent(AdEvent.SKIPPED,hasLeaveBehind));
         }
      }
      
      private function showCompanion() : void
      {
         var _loc2_:Sprite = null;
         var _loc3_:Sprite = null;
         var _loc4_:Sprite = null;
         log("showCompanion()");
         if(companionHtml == null)
         {
            log("companionHtml is null");
            return;
         }
         var _loc1_:Object = HTMLCompanion.parseHTML(companionHtml,new Object());
         if(layout == "rightsidecompanion")
         {
            _loc2_ = new Sprite();
            _loc2_.graphics.beginFill(0);
            _loc2_.graphics.drawRect(-2,-2,304,254);
            _loc2_.graphics.endFill();
            _loc2_.scaleX = scaleFactor;
            _loc2_.scaleY = scaleFactor;
            _loc3_ = new Sprite();
            _loc2_.addChild(_loc3_);
            _loc4_ = new Sprite();
            _loc4_.graphics.beginFill(0);
            _loc4_.graphics.drawRect(0,0,300,250);
            _loc4_.graphics.endFill();
            _loc4_.visible = false;
            _loc3_.addChild(_loc4_);
            _loc3_.mask = _loc4_;
            overlay_ad_mc_parent.addChild(_loc2_);
            HTMLCompanion.parseCompanionNodes(_loc3_,_loc1_);
            _loc3_.soundTransform = new SoundTransform(0);
            _loc2_.x = overlayLoader.x + videoWidth + 4;
            _loc2_.y = (totalHeight - 250 * scaleFactor) / 2;
         }
         else
         {
            HTMLCompanion.parseCompanionNodes(ad_mc_parent,_loc1_);
            if(AdEvent)
            {
               sendEventToContainer(new AdEvent(AdEvent.LEAVE_BEHIND,hasLeaveBehind));
            }
         }
         companionHtml = null;
      }
      
      private function showLeaveBehindFlashUrl() : void
      {
         if(leaveBehindFlashUrl != null)
         {
            swfLoader = new Loader();
            swfLoader.contentLoaderInfo.addEventListener(Event.INIT,swfInitHandler);
            swfLoader.contentLoaderInfo.addEventListener(Event.COMPLETE,swfCompleteHandler);
            swfLoader.addEventListener(Event.ADDED_TO_STAGE,swfAddedHandler);
            swfLoader.load(new URLRequest(leaveBehindFlashUrl));
            swfLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,errorHandler);
            swfLoader.visible = false;
            addChild(swfLoader);
            if(muteLeaveBehind)
            {
               SoundMixer.soundTransform = new SoundTransform(0);
            }
         }
      }
      
      private function progressBarEnterFrameHandler1(param1:Event) : void
      {
         var _loc3_:Number = Math.min(1,(getTimer() - progressBarStartTime) / 10000);
         progressBarForeground.scaleX = _loc3_;
         if(_loc3_ >= 1)
         {
            param1.currentTarget.removeEventListener(Event.ENTER_FRAME,arguments.callee);
            if(lc != null)
            {
               try
               {
                  lc.send(lcName + "_","skip");
               }
               catch(e:Error)
               {
               }
            }
            log("progressBarEnterFrameHandler1: t>=1");
            removeOverlay();
         }
      }
      
      private function progressBarEnterFrameHandler2(param1:Event) : void
      {
         var _loc3_:Number = (getTimer() - progressBarStartTime) / 1000;
         var _loc4_:Number = Math.min(1,(getTimer() - progressBarStartTime) / adDuration);
         progressBarForeground.scaleX = _loc4_;
         if((_loc4_ >= skipFraction || _loc3_ > skipSeconds) && skipButton.visible == false)
         {
            showSkipButton();
         }
         if(_loc4_ >= 1)
         {
            param1.currentTarget.removeEventListener(Event.ENTER_FRAME,arguments.callee);
         }
      }
      
      private function showSkipButton() : void
      {
         if(skipButton == null || skipButton.visible)
         {
            return;
         }
         skipButton.visible = true;
         skipButtonStartTime = getTimer();
         skipButton.addEventListener(Event.ENTER_FRAME,function(param1:Event):void
         {
            var _loc3_:Number = Math.min(1,(getTimer() - skipButtonStartTime) / 1000);
            skipButton.alpha = _loc3_;
            if(_loc3_ == 1)
            {
               param1.currentTarget.removeEventListener(Event.ENTER_FRAME,arguments.callee);
            }
         });
         if(AdEvent)
         {
            sendEventToContainer(new AdEvent(AdEvent.SKIP_ALLOWED,hasLeaveBehind));
         }
      }
      
      private function overlayEnterFrameHandlerFadeOn(param1:Event) : void
      {
         if(overlay == null)
         {
            return;
         }
         var _loc3_:Number = Math.min(1,(getTimer() - coverStartTime) / 500);
         overlay.alpha = _loc3_;
         if(_loc3_ == 1)
         {
            param1.currentTarget.removeEventListener(Event.ENTER_FRAME,arguments.callee);
            log("overlayEnterFrameHandlerFadeOn completed");
         }
      }
      
      private function overlayEnterFrameHandlerFadeOff(param1:Event) : void
      {
         if(overlay == null)
         {
            return;
         }
         var _loc3_:Number = Math.max(0,1 - (getTimer() - overlayStartTime) / 500);
         overlay.alpha = _loc3_;
         if(_loc3_ == 0)
         {
            param1.currentTarget.removeEventListener(Event.ENTER_FRAME,arguments.callee);
            log("overlayEnterFrameHandlerFadeOff completing");
            overlay.parent.removeChild(overlay);
         }
      }
      
      private function removeOverlay() : void
      {
         var _loc1_:String = null;
         log("removeOverlay()");
         log("removeOverlay: overlay = " + overlay);
         log("removeOverlay: overlayRemoved = " + overlayRemoved);
         if(swfLoader != null)
         {
            log("removeOverlay: swf loader not null");
            swfLoader.visible = true;
         }
         if(overlay != null && !overlayRemoved)
         {
            overlayRemoved = true;
            log("removeOverlay: overlay != null && !overlayRemoved");
            if(skipButton != null)
            {
               skipButton.visible = false;
            }
            if(progressBar != null && progressBar.hasEventListener(Event.ENTER_FRAME))
            {
               progressBar.removeEventListener(Event.ENTER_FRAME,progressBarEnterFrameHandler2);
            }
            if(overlayShown)
            {
               log("removeOverlay: overlayShown -> show leave behind");
               overlayStartTime = getTimer();
               overlay.addEventListener(Event.ENTER_FRAME,overlayEnterFrameHandlerFadeOff);
               if(layout != "rightsidecompanion")
               {
                  showCompanion();
               }
               if(!skipped && Boolean(AdEvent))
               {
                  sendEventToContainer(new AdEvent(AdEvent.OVERLAY_COMPLETE,hasLeaveBehind));
               }
               showLeaveBehindFlashUrl();
            }
            else
            {
               log("removeOverlay: !overlayShown -> maybe try another one");
               overlay.parent.removeChild(overlay);
               if(overlayAddedToStage)
               {
                  muteLeaveBehind = false;
                  skipSeconds = 100;
                  skipFraction = 0.25;
                  layout = null;
                  blockChildAds = false;
                  _loc1_ = "";
                  if(passbackError != null && passbackError != "")
                  {
                     _loc1_ = passbackError;
                  }
                  else
                  {
                     _loc1_ = cpmstar_url;
                     if(overlayAttempts >= 3)
                     {
                        log("removeOverlay: too many attempts: attempt #: " + overlayAttempts);
                        _loc1_ += "&adtypeid=14";
                     }
                     else
                     {
                        log("removeOverlay: attempt #: " + overlayAttempts);
                        overlayAttempts += 1;
                        overlayRemoved = false;
                     }
                     if(campaignID != 0)
                     {
                        _loc1_ += "&defaultcampaignid=" + campaignID;
                     }
                     log("removeOverlay: next attempt: " + _loc1_);
                  }
                  urlLoader.load(new URLRequest(_loc1_));
               }
            }
            if(lc != null)
            {
               try
               {
                  lc.close();
               }
               catch(e:Error)
               {
               }
               lc = null;
            }
            if(overlay_ad_mc_parent != null)
            {
               overlay_ad_mc_parent.soundTransform = new SoundTransform(0,0);
            }
         }
         else
         {
            log("removeOverlay: called again, but overlay = null || overlayRemoved ");
            log("removeOverlay: overlay = " + overlay);
            log("removeOverlay: overlayRemoved = " + overlayRemoved);
            if(overlay != null && overlay.parent != null)
            {
               overlay.parent.removeChild(overlay);
            }
            if(!overlayShown)
            {
               sendEventToContainer(new Event("CpmstarVideoAdError",true,false));
            }
         }
      }
      
      private function swfInitHandler(param1:Event) : void
      {
         var _loc2_:Sprite = new Sprite();
         _loc2_.graphics.beginFill(0);
         _loc2_.graphics.drawRect(0,0,300,250);
         _loc2_.graphics.endFill();
         addChild(_loc2_);
         swfLoader.mask = _loc2_;
         swfLoader.visible = true;
      }
      
      private function swfCompleteHandler(param1:Event) : void
      {
         checkAdBlock();
         var _loc2_:LoaderInfo = Loader(param1.target.loader).contentLoaderInfo;
         completed = true;
         tryToSetFramerate(param1.target.loader);
         if(AdEvent)
         {
            sendEventToContainer(new AdEvent(AdEvent.LEAVE_BEHIND,hasLeaveBehind));
         }
         var _loc3_:Timer = new Timer(300,1);
         _loc3_.addEventListener(TimerEvent.TIMER,showCursor);
         _loc3_.start();
      }
      
      private function swfAddedHandler(param1:Event) : void
      {
         added = true;
         tryToSetFramerate(DisplayObject(param1.target));
      }
      
      private function tryToSetFramerate(param1:DisplayObject) : void
      {
         if(!completed || !added)
         {
            return;
         }
      }
      
      private function errorHandler(param1:Event) : void
      {
         checkAdBlock();
         swfRemovedHandler(param1);
         if(AdEvent)
         {
            sendEventToContainer(new AdEvent(AdEvent.ERROR,hasLeaveBehind));
         }
         sendEventToContainer(new Event("AdError",true,false));
      }
      
      private function checkAdBlock() : void
      {
         if(adblockChecked)
         {
            return;
         }
         adblockChecked = true;
         if(Boolean(parameters.contentspotid) || Boolean(parameters.poolid) || parameters["&amp;poolid"] != null)
         {
            bcLoader.addEventListener(Event.COMPLETE,bcCompleteHandler);
            bcLoader.addEventListener(IOErrorEvent.IO_ERROR,bcErrorHandler);
            bcLoader.load(new URLRequest("http://server.cpmstar.com/cached/flashadv11.js"));
         }
      }
      
      private function bcCompleteHandler(param1:Event) : void
      {
         trueUpB(1);
      }
      
      private function bcErrorHandler(param1:Event) : void
      {
         trueUpB(2);
      }
      
      private function trueUpB(param1:int) : void
      {
         var _loc2_:String = null;
         var _loc3_:String = null;
         var _loc4_:int = 0;
         if(parameters.contentspotid != null)
         {
            _loc3_ = parameters.contentspotid;
            _loc4_ = _loc3_.indexOf("Q");
            _loc2_ = _loc3_.substr(0,_loc4_);
         }
         else if(parameters["amp;poolid"] != null)
         {
            _loc2_ = parameters["amp;poolid"];
         }
         else
         {
            _loc2_ = parameters.poolid;
         }
         bcLoader = new URLLoader();
         bcLoader.load(new URLRequest("http://server.cpmstar.com/trueup.aspx?poolid=" + _loc2_ + "&b=" + param1));
      }
      
      private function sendEventToContainer(param1:Event) : void
      {
         try
         {
            parent.parent.dispatchEvent(param1);
         }
         catch(e:Error)
         {
         }
      }
      
      private function swfRemovedHandler(param1:Event) : void
      {
         var event:Event = param1;
         log("swfRemovedHandler()");
         if(event.currentTarget == this)
         {
            removeEventListener(Event.REMOVED_FROM_STAGE,swfRemovedHandler);
            log("event.currentTarget == this");
            try
            {
               addChildAd();
               if(swfLoader != null)
               {
                  swfLoader.unload();
                  if(swfLoader.parent != null)
                  {
                     swfLoader.parent.removeChild(swfLoader);
                  }
                  swfLoader = null;
                  if(pixelLoader != null)
                  {
                     pixelLoader.unload();
                     pixelLoader = null;
                  }
               }
               if(ad_mc_parent != null)
               {
                  ad_mc_parent.parent.removeChild(ad_mc_parent);
                  ad_mc_parent = null;
               }
               if(overlay != null)
               {
                  if(overlayLoader != null)
                  {
                     try
                     {
                        log("trying overlayLoader[unloadAndStop]()");
                        overlayLoader["unloadAndStop"]();
                        log("success");
                     }
                     catch(e:Error)
                     {
                        log("failed");
                        overlayLoader.unload();
                        log("unloaded");
                     }
                  }
                  if(overlay != null)
                  {
                     if(overlay.parent != null)
                     {
                        overlay.parent.removeChild(overlay);
                     }
                     overlay = null;
                  }
               }
               if(lc != null)
               {
                  lc.close();
                  lc = null;
               }
               log("calling HTMLCompanion.cleanup()");
               HTMLCompanion.cleanup();
               try
               {
                  SoundMixer.soundTransform = new SoundTransform(startVolume);
               }
               catch(e:Error)
               {
               }
               try
               {
                  top.removeEventListener(MouseEvent.MOUSE_OVER,showCursor);
                  log("removed Mouse_Over EventListener");
               }
               catch(e:Error)
               {
               }
            }
            catch(e:Error)
            {
               log("swfRemoveHandler error: " + e.message);
               log("STACKTRACE=" + e.getStackTrace());
               log("swfRemoveHandler end error");
            }
         }
      }
      
      private function getReferrer() : String
      {
         var _loc1_:String = null;
         try
         {
            _loc1_ = String(ExternalInterface.call("function(){return location.href;}"));
         }
         catch(e:Error)
         {
         }
         if(_loc1_ == null)
         {
            _loc1_ = top.loaderInfo.loaderURL;
         }
         return _loc1_;
      }
   }
}

