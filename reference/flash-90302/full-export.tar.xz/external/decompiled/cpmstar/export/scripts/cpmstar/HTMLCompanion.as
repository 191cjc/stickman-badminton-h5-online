package cpmstar
{
   import flash.display.*;
   import flash.events.*;
   import flash.external.ExternalInterface;
   import flash.net.*;
   import flash.utils.*;
   
   public class HTMLCompanion
   {
      
      private static var realRoot:DisplayObjectContainer;
      
      private static const ws:Array = [" ","\t","\r","\n"];
      
      private static const wse:Array = [" ","\t","\r","\n","="];
      
      private static var loaders:Array = [];
      
      private static var hrefUrl:String = null;
      
      private static var parseFns:Object = {
         "a":parseAnchor,
         "img":parseImg,
         "iframe":parseIFrame,
         "html":parseHtmlTag,
         "body":parseRecurse,
         "noscript":parseRecurse,
         "span":parseRecurse,
         "div":parseRecurse,
         "table":parseRecurse,
         "tr":parseRecurse,
         "td":parseRecurse,
         "object":parseObject
      };
      
      public function HTMLCompanion()
      {
         super();
      }
      
      public static function indexOfAny(param1:String, param2:Array, param3:Number) : Number
      {
         var _loc6_:Number = NaN;
         var _loc7_:String = null;
         var _loc8_:String = null;
         var _loc4_:Number = param1.length;
         var _loc5_:Number = param2.length;
         while(param3 < _loc4_)
         {
            _loc6_ = 0;
            while(_loc6_ < _loc5_)
            {
               _loc7_ = param1.charAt(param3);
               _loc8_ = param2[_loc6_];
               if(_loc7_ == _loc8_)
               {
                  break;
               }
               _loc6_++;
            }
            if(_loc6_ < _loc5_)
            {
               break;
            }
            param3++;
         }
         if(param3 == _loc4_)
         {
            param3 = -1;
         }
         return param3;
      }
      
      public static function lastIndexOfAny(param1:String, param2:Array, param3:Number) : Number
      {
         var _loc5_:Number = NaN;
         var _loc6_:String = null;
         var _loc7_:String = null;
         var _loc4_:Number = param2.length;
         while(param3 >= 0)
         {
            _loc5_ = 0;
            while(_loc5_ < _loc4_)
            {
               _loc6_ = param1.charAt(param3);
               _loc7_ = param2[_loc5_];
               if(_loc6_ == _loc7_)
               {
                  break;
               }
               _loc5_++;
            }
            if(_loc5_ < _loc4_)
            {
               break;
            }
            param3--;
         }
         return param3;
      }
      
      public static function indexOfNotAny(param1:String, param2:Array, param3:Number) : Number
      {
         var _loc6_:Number = NaN;
         var _loc7_:String = null;
         var _loc8_:String = null;
         var _loc4_:Number = param1.length;
         var _loc5_:Number = param2.length;
         while(param3 < _loc4_)
         {
            _loc6_ = 0;
            while(_loc6_ < _loc5_)
            {
               _loc7_ = param1.charAt(param3);
               _loc8_ = param2[_loc6_];
               if(_loc7_ == _loc8_)
               {
                  break;
               }
               _loc6_++;
            }
            if(_loc6_ == _loc5_)
            {
               break;
            }
            param3++;
         }
         if(param3 == _loc4_)
         {
            param3 = -1;
         }
         return param3;
      }
      
      public static function lastIndexOfNotAny(param1:String, param2:Array, param3:Number) : Number
      {
         var _loc5_:Number = NaN;
         var _loc6_:String = null;
         var _loc7_:String = null;
         var _loc4_:Number = param2.length;
         while(param3 >= 0)
         {
            _loc5_ = 0;
            while(_loc5_ < _loc4_)
            {
               _loc6_ = param1.charAt(param3);
               _loc7_ = param2[_loc5_];
               if(_loc6_ == _loc7_)
               {
                  break;
               }
               _loc5_++;
            }
            if(_loc5_ == _loc4_)
            {
               break;
            }
            param3--;
         }
         return param3;
      }
      
      public static function parseHTML(param1:String, param2:Object) : Object
      {
         var _loc4_:Number = NaN;
         var _loc5_:Number = NaN;
         var _loc6_:String = null;
         var _loc7_:Number = NaN;
         var _loc8_:Number = NaN;
         var _loc9_:Boolean = false;
         var _loc10_:Array = null;
         var _loc11_:Object = null;
         var _loc12_:String = null;
         var _loc13_:Number = NaN;
         var _loc14_:Number = NaN;
         var _loc15_:Number = NaN;
         var _loc16_:Number = NaN;
         var _loc17_:Number = NaN;
         var _loc18_:Number = NaN;
         var _loc19_:String = null;
         var _loc20_:Number = NaN;
         var _loc3_:Number = 0;
         while(true)
         {
            _loc3_ = param1.indexOf("<",_loc3_);
            if(!(_loc3_ < param1.length && _loc3_ != -1))
            {
               break;
            }
            if(param1.substr(_loc3_,4) == "<!--")
            {
               _loc4_ = param1.indexOf("-->",_loc3_ + 1);
               if(_loc4_ == -1)
               {
                  break;
               }
               _loc3_ = _loc4_ + 1;
            }
            else
            {
               _loc4_ = param1.indexOf(">",_loc3_ + 1);
               if(_loc4_ == -1)
               {
                  break;
               }
               _loc5_ = indexOfAny(param1,ws,_loc3_ + 1);
               if(_loc5_ == _loc3_ + 1)
               {
                  break;
               }
               if(_loc5_ == -1 || _loc5_ > _loc4_)
               {
                  _loc5_ = _loc4_;
                  if(param1.charAt(_loc4_ - 1) == "/")
                  {
                     _loc5_ = _loc4_ - 1;
                  }
               }
               _loc6_ = param1.substring(_loc3_ + 1,_loc5_).toLowerCase();
               _loc7_ = _loc3_;
               _loc8_ = _loc4_;
               _loc9_ = param1.charAt(_loc4_ - 1) == "/";
               if(!_loc9_)
               {
                  _loc7_ = param1.toLowerCase().indexOf("</" + _loc6_ + ">",_loc4_ + 1);
                  if(_loc7_ == -1)
                  {
                     _loc8_ = _loc4_;
                  }
                  else
                  {
                     _loc8_ = _loc7_ + ("</" + _loc6_ + ">").length - 1;
                  }
               }
               _loc10_ = param2[_loc6_];
               if(_loc10_ == null)
               {
                  _loc10_ = param2[_loc6_] = new Array();
               }
               _loc11_ = new Object();
               _loc10_.push(_loc11_);
               _loc12_ = param1.substring(_loc5_,_loc9_ ? _loc4_ - 1 : _loc4_);
               _loc13_ = 0;
               do
               {
                  _loc14_ = indexOfNotAny(_loc12_,ws,_loc13_);
                  if(_loc14_ == -1)
                  {
                     break;
                  }
                  _loc15_ = _loc12_.indexOf("=",_loc14_);
                  if(_loc15_ == -1)
                  {
                     break;
                  }
                  _loc16_ = indexOfAny(_loc12_,wse,_loc14_);
                  if(_loc16_ == -1)
                  {
                     break;
                  }
                  if(_loc16_ != _loc15_)
                  {
                     _loc20_ = indexOfNotAny(_loc12_,ws,_loc16_);
                     if(_loc20_ != -1 && _loc20_ < _loc15_)
                     {
                        _loc13_ = _loc20_;
                        continue;
                     }
                  }
                  _loc18_ = indexOfNotAny(_loc12_,ws,_loc15_ + 1);
                  if(_loc18_ == -1)
                  {
                     _loc17_ = _loc18_;
                     _loc13_ = _loc17_ + 1;
                  }
                  _loc19_ = _loc12_.charAt(_loc18_);
                  if(_loc19_ == "\'" || _loc19_ == "\"")
                  {
                     _loc17_ = _loc12_.indexOf(_loc19_,_loc18_ + 1);
                     if(_loc17_ == -1)
                     {
                        break;
                     }
                     _loc18_ += 1;
                     _loc13_ = _loc17_ + 1;
                  }
                  else
                  {
                     _loc17_ = indexOfAny(_loc12_,ws,_loc18_ + 1);
                     if(_loc17_ == -1)
                     {
                        break;
                     }
                     _loc13_ = _loc17_;
                  }
                  _loc11_["@" + _loc12_.substring(_loc14_,_loc16_).toLowerCase()] = _loc12_.substring(_loc18_,_loc17_);
               }
               while(_loc13_ < _loc12_.length);
               if(_loc8_ != _loc4_)
               {
                  _loc11_["nodeContents"] = param1.substring(_loc4_ + 1,_loc7_);
                  parseHTML(param1.substring(_loc4_ + 1,_loc7_),_loc11_);
               }
               _loc3_ = _loc8_ + 1;
            }
         }
         return param2;
      }
      
      public static function parseCompanionNodes(param1:DisplayObjectContainer, param2:Object) : void
      {
         HTMLCompanion.realRoot = param1;
         delete parseFns["script"];
         parseFns["noscript"] = parseRecurse;
         parseRecurse(param2,null);
      }
      
      public static function parseRecurse(param1:Object, param2:String) : void
      {
         var _loc3_:String = null;
         var _loc4_:Function = null;
         var _loc5_:Number = NaN;
         for(_loc3_ in param1)
         {
            _loc4_ = parseFns[_loc3_];
            if(_loc4_ != null)
            {
               _loc5_ = 0;
               while(_loc5_ < param1[_loc3_].length)
               {
                  _loc4_(param1[_loc3_][_loc5_],param2);
                  _loc5_++;
               }
            }
         }
      }
      
      public static function parseHtmlTag(param1:Object, param2:String) : void
      {
         if(param1["@clickthrough"] != null)
         {
            HTMLCompanion.hrefUrl = param1["@clickthrough"];
         }
         if(param1["@parsescripts"] != null)
         {
            parseFns["script"] = parseScript;
            delete parseFns["noscript"];
         }
         parseRecurse(param1,param2);
      }
      
      public static function parseScript(param1:Object, param2:String) : void
      {
         var loader:URLLoader = null;
         var xml:Object = param1;
         var href:String = param2;
         if(xml["@src"] != null)
         {
            loader = new URLLoader();
            loaders.push(loader);
            loader.addEventListener(Event.COMPLETE,onLoadScript);
            loader.addEventListener(IOErrorEvent.IO_ERROR,function(param1:Event):void
            {
            });
            loader.load(new URLRequest(xml["@src"]));
         }
         else
         {
            renderJavascript(xml["nodeContents"]);
         }
      }
      
      public static function onLoadScript(param1:Event) : void
      {
         var _loc2_:URLLoader = URLLoader(param1.target);
         var _loc3_:String = _loc2_.data;
         renderJavascript(_loc3_);
      }
      
      public static function renderJavascript(param1:String) : void
      {
         var _loc3_:Number = NaN;
         var _loc4_:Number = NaN;
         var _loc5_:String = null;
         var _loc2_:Number = param1.toLowerCase().indexOf(".swf");
         if(_loc2_ != -1)
         {
            _loc3_ = Math.max(param1.lastIndexOf("\'",_loc2_),param1.lastIndexOf("\"",_loc2_));
            if(_loc3_ != -1)
            {
               _loc4_ = param1.indexOf(param1.charAt(_loc3_),_loc2_);
               if(_loc4_ != -1)
               {
                  if(param1.substr(_loc3_ - 2,2).indexOf("+") == -1)
                  {
                     if(param1.substr(_loc4_ + 1,2).indexOf("+") == -1)
                     {
                        _loc5_ = param1.substring(_loc3_ + 1,_loc4_);
                        addCompanion(_loc5_,hrefUrl);
                     }
                  }
               }
            }
         }
      }
      
      public static function parseObject(param1:Object, param2:String) : void
      {
         if(param1["@data"] != null)
         {
            if(param1["@data"].toLowerCase().indexOf(".swf") != -1 || param1["@type"] != null && param1["@type"].toLowerCase() == "application/x-shockwave-flash")
            {
               addCompanion(param1["@data"],hrefUrl);
            }
         }
      }
      
      public static function parseIFrame(param1:Object, param2:String) : void
      {
         var loader:URLLoader;
         var xml:Object = param1;
         var href:String = param2;
         if(String(xml["@src"]).toLowerCase().indexOf("about:") == 0)
         {
            return;
         }
         loader = new URLLoader();
         loaders.push(loader);
         loader.addEventListener(Event.COMPLETE,onLoadIFrame);
         loader.addEventListener(IOErrorEvent.IO_ERROR,function(param1:Event):void
         {
         });
         loader.load(new URLRequest(xml["@src"]));
      }
      
      public static function onLoadIFrame(param1:Event) : void
      {
         var _loc2_:URLLoader = URLLoader(param1.target);
         var _loc3_:String = _loc2_.data;
         var _loc4_:Object = parseHTML(_loc3_,new Object());
         parseRecurse(_loc4_,null);
      }
      
      public static function parseAnchor(param1:Object, param2:String) : void
      {
         param2 = param1["@href"];
         parseRecurse(param1,param2);
      }
      
      public static function parseImg(param1:Object, param2:String) : void
      {
         var _loc3_:Number = int(param1["@width"]);
         var _loc4_:Number = int(param1["@height"]);
         var _loc5_:String = String(param1["@src"]);
         var _loc6_:String = String(param1["@style"]);
         if(_loc6_.toLowerCase().indexOf("display:none") != -1 || param1["@width"] != null && _loc3_ <= 1 && param1["@height"] != null && _loc4_ <= 1)
         {
            hitPixel(_loc5_);
         }
         else
         {
            addCompanion(_loc5_,param2);
         }
      }
      
      private static function addCompanion(param1:String, param2:String) : void
      {
         var companionAd:Loader;
         var src:String = param1;
         var href:String = param2;
         var companionAdParent:Sprite = new Sprite();
         realRoot.addChild(companionAdParent);
         companionAd = new Loader();
         loaders.push(companionAd);
         companionAdParent.addChild(companionAd);
         companionAd.load(new URLRequest(src));
         companionAd.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,function(param1:Event):void
         {
            param1.currentTarget.removeEventListener(IOErrorEvent.IO_ERROR,arguments.callee);
         });
         if(href != null && href != "undefined")
         {
            HTMLCompanion.hrefUrl = href;
            companionAdParent.buttonMode = true;
            companionAdParent.useHandCursor = true;
            companionAdParent.mouseChildren = false;
            companionAdParent.mouseEnabled = true;
            companionAdParent.addEventListener(MouseEvent.CLICK,function(param1:Event):void
            {
               var _loc2_:String = ExternalInterface.call("function getBrowser(){return navigator.userAgent;}");
               if(_loc2_ != null && _loc2_.indexOf("MSIE") >= 0 && ExternalInterface.available)
               {
                  ExternalInterface.call("function setWMWindow() {window.open(\'" + new URLRequest(HTMLCompanion.hrefUrl) + "\');}");
               }
               else
               {
                  navigateToURL(new URLRequest(HTMLCompanion.hrefUrl),"_blank");
               }
            });
         }
      }
      
      private static function hitPixel(param1:String) : void
      {
         var _loc2_:Loader = null;
         if(param1 != null && param1 != "")
         {
            _loc2_ = new Loader();
            _loc2_.load(new URLRequest(param1));
            loaders.push(_loc2_);
         }
      }
      
      public static function cleanup() : void
      {
         var _loc1_:* = undefined;
         for each(_loc1_ in loaders)
         {
            if(_loc1_ is Loader)
            {
               Loader(_loc1_).unload();
            }
         }
         loaders = null;
      }
   }
}

