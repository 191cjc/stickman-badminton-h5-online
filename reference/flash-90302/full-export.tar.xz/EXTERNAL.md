# External dependency boundary

Game-internal characters, menus, effects (BigSpark/ParticleBirdie included), audio and timelines are embedded in original.swf. All original ABC constant strings are retained in original.xml and raw ABC, with URL/domain/path matches in abc-url-constants.json. There are no ImportAssets or separate gameplay art fetches in the published game.

## Direct public loaders

- Kongregate: bobby/§_-6§.as:50 defaults to http://www.kongregate.com/flash/API_AS3_Local.swf; the page could override it with kongregate_api_path. The default URL redirected to HTTPS and returned a valid 11,114-byte SWF. Both HTTP/HTTPS evidence and files are saved. The full available loader scripts/resources/XML/pcode are recovered under external/decompiled/kongregate.
- CPMStar: CPMStar/AdLoader.as:21 builds http://server.cpmstar.com/adviewas3.swf. Intro §_-2s§/§_-53§.as:63 uses poolid12941/subpoolid7; ui/DeathScreen.as:101 uses12941/8. All four HTTP/HTTPS requests returned the same valid13,558-byte SWF; each response is saved and one full recovery is under external/decompiled/cpmstar.
- These files are current download snapshots, not proof of their exact2012 versions. None were executed.

## Services and variable content

- Playtomic: Main.as:41 configures SWFID8120 and GUID9fd05594863e41dc; Log.as:114 loads http(s)://g9fd05594863e41dc.api.playtomic.com/crossdomain.xml. Both schemes failed DNS resolution; exact errors are in external/requests.json. Stats/leaderboard/player-level API request code remains in all original script/ABC copies. No API writes were sent.
- Playtomic.PlayerLevel ThumbUrl uses a variable remote level ID, and is a library facility, not an embedded game art path. No game callsite references PlayerLevels/PlayerLevel outside the library initialization.
- The recovered Kongregate API supplies local-test shadow services and interfaces; online account/store/chat/service implementations are remote and cannot be recovered as author game source.
- CPMStar's current recovered AdView requests variable ad-server responses, campaign assets, tracking pixels and companion ads. Those responses are changing third-party service content, not game source. The static helper references are documented separately in external/transitive-requests.json where downloaded; no impression/stat/tracking endpoint is executed.
- The static watermark helper was downloaded over its HTTPS CDN (2,955 bytes) and fully exported as AS1/2 actions, resources, XML and P-code under external/decompiled/cpmstar-watermark. The HTTP CDN request failed from this host (network unreachable). The static flashadv11.js helper (3,244 bytes) was also saved. The watermark itself requests changing advertisement content, which is a service boundary. external/RECOVERY.json checks script identity counts for all three loader recoveries (29 AS3, 2 AS3, 10 AS1/2 action blocks respectively).
- Conversion limit in the supplementary watermark only: DefineFont3 ID2 (Arial normal) and ID6 (Arial bold) have zero glyphs and zero codeTable entries. They are device-font placeholders; there is no embedded font data to recover as standalone TTF. JPEXS therefore exports no TTF for them. Both definitions remain intact in the downloaded watermark SWF and its complete XML. This is distinct from the main game's seven embedded fonts, all of which are exported. External per-ID coverage and exceptions are recorded in external/RECOVERY.json.
- Sponsor/credits links (EffingGames, Kongregate, HybridWing), Adobe namespace strings, site-lock domains and library error/help example URLs are not missing game code/resources.

The complete public game SWF is the lossless archival boundary. No author editable FLA/AS project, private server source, original third-party service implementation or historical ad inventory is claimed to have been obtained. Reconstructed XFL is generated from the published binary and is labelled as such.
